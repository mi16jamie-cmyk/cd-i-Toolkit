/* hello - the smallest CD-i program worth running: text, colours, and a
 * box you move with the controller. Button 1 changes its colour. */
#include "cdi.h"

int main(void)
{
    if (gfx_init()) return 1;
    static const u32 colours[] = {
        0x000000,   /* 0: see-through */
        0x101838,   /* 1: background */
        0xFFFFFF,   /* 2: white */
        0xFFD000,   /* 3: yellow */
        0xFF4040, 0x40FF40, 0x4080FF,   /* 4..6: the box */
    };
    gfx_palette(colours, 0, 7);
    gfx_background(0, 1);           /* gfx_restore() puts colour 1 back */

    int x = 176, y = 160, c = 4;
    for (;;) {
        u16 pad = pad_read();
        if (pad & PAD_LEFT) x -= 4;
        if (pad & PAD_RIGHT) x += 4;
        if (pad & PAD_UP) y -= 4;
        if (pad & PAD_DOWN) y += 4;
        if (x < 0) x = 0;
        if (x > GFX_W - 32) x = GFX_W - 32;
        if (y < 120) y = 120;
        if (y > GFX_H - 32) y = GFX_H - 32;
        if (pad_pressed() & PAD_B1) c = c == 6 ? 4 : c + 1;

        gfx_restore();              /* last frame's drawing away */
        gfx_label(0, 40, 40, "Hello, CD-i!", 3, 4);
        gfx_label(1, 40, 90, "Move the box with the controller;", 2, 1);
        gfx_label(2, 40, 102, "button 1 changes its colour.", 2, 1);
        gfx_rect(x, y, 32, 32, c);
        gfx_swap();
    }
}
