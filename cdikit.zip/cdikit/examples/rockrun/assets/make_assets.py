#!/usr/bin/env python3
"""make_assets.py - makes the example's source assets as ordinary files, so
the example needs nothing copyrighted (in a real project these are your
own PNGs, WAVs and videos):
  title.png      384 x 280 title picture
  space.png      384 x 280 background for players without the cartridge
  sprites.png    a sheet of 32 x 32 sprites: ship, 2 rocks, shot, 4 bangs
  laser.wav boom.wav pickup.wav     sound effects
  music.wav      a 32-second tune (title music and in-game music)
  flight.mp4     a 32-second flight through space (the MPEG background)"""
import math, os, random, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw
here = os.path.dirname(os.path.abspath(__file__))
os.chdir(here)
random.seed(7); rng = np.random.default_rng(7)
W, H = 384, 280

# ---------------------------------------------------------------- pictures
def stars(img, n, seed):
    r = random.Random(seed); d = ImageDraw.Draw(img)
    for _ in range(n):
        x, y, b = r.randrange(W), r.randrange(H), r.randrange(80, 256)
        d.point((x, y), (b, b, min(255, b + 30)))

bg = Image.new('RGB', (W, H))
px = bg.load()
for y in range(H):
    for x in range(W):
        t = y / H
        px[x, y] = (int(10 + 30 * t), int(5 + 10 * t), int(40 + 50 * (1 - t)))
stars(bg, 300, 1)
d = ImageDraw.Draw(bg)
d.ellipse((250, 150, 420, 320), fill=(120, 60, 40)); d.ellipse((262, 160, 410, 300), fill=(160, 90, 60))
for i in range(6): d.arc((240 - i * 4, 210 - i, 430 + i * 4, 260 + i), 180, 360, fill=(200, 170, 120))
bg.save('space.png')

title = bg.copy(); d = ImageDraw.Draw(title)
for i, c in enumerate([(255, 80, 40), (255, 160, 40), (255, 230, 80)]):
    d.rectangle((40 + i * 3, 60 + i * 3, 344 - i * 3, 64 + i * 3), fill=c)
    d.rectangle((40 + i * 3, 136 - i * 3, 344 - i * 3, 140 - i * 3), fill=c)
title.save('title.png')

S = 32
sheet = Image.new('RGBA', (S * 8, S), (0, 0, 0, 0)); d = ImageDraw.Draw(sheet)
# 0 ship
d.polygon([(16, 2), (28, 28), (16, 22), (4, 28)], fill=(200, 210, 230)); d.polygon([(16, 8), (21, 22), (11, 22)], fill=(60, 140, 255))
d.rectangle((13, 26, 19, 30), fill=(255, 160, 40))
# 1, 2 rocks
for k, (ox, col) in enumerate([(S, (150, 120, 100)), (2 * S, (120, 110, 130))]):
    r = random.Random(k + 3)
    pts = [(ox + 16 + (11 + r.randrange(4)) * math.cos(a), 16 + (11 + r.randrange(4)) * math.sin(a))
           for a in [i * math.pi / 5 for i in range(10)]]
    d.polygon(pts, fill=col); d.ellipse((ox + 9, 9, ox + 15, 15), fill=tuple(c - 40 for c in col))
    d.ellipse((ox + 18, 17, ox + 22, 21), fill=tuple(c - 40 for c in col))
# 3 shot
d.rectangle((3 * S + 14, 6, 3 * S + 17, 26), fill=(120, 255, 120)); d.rectangle((3 * S + 15, 8, 3 * S + 16, 24), fill=(230, 255, 230))
# 4..7 explosion
for k in range(4):
    ox = (4 + k) * S; rr = 5 + k * 3
    for j in range(12):
        a = j * math.pi / 6 + k * 0.3; L = rr + (j % 3) * 2
        d.line((ox + 16, 16, ox + 16 + L * math.cos(a), 16 + L * math.sin(a)), fill=(255, 200 - k * 40, 40), width=2)
    d.ellipse((ox + 16 - rr // 2, 16 - rr // 2, ox + 16 + rr // 2, 16 + rr // 2), fill=(255, 255, 160 - k * 30))
sheet.save('sprites.png')

# ---------------------------------------------------------------- sounds
R = 44100
def save(name, s):
    s = np.clip(s, -1, 1)
    with wave.open(name, 'wb') as w:
        w.setnchannels(1 if s.ndim == 1 else 2); w.setsampwidth(2); w.setframerate(R)
        w.writeframes((s * 32000).astype('<i2').tobytes())
def env(n, a=0.005, r=None):
    t = np.arange(n) / R; e = np.minimum(1, t / a)
    return e * (np.exp(-t / r) if r else 1)
t = np.arange(int(R * 0.25)) / R
save('laser.wav', np.sign(np.sin(2 * np.pi * np.cumsum(1800 * np.exp(-t * 12) + 200) / R)) * 0.4 * env(len(t), r=0.08))
t = np.arange(int(R * 0.8)) / R
noise = rng.standard_normal(len(t)); lp = np.convolve(noise, np.ones(30) / 30, 'same')
save('boom.wav', lp * 3 * env(len(t), r=0.25) + np.sin(2 * np.pi * 60 * t) * env(len(t), r=0.15) * 0.6)
t = np.arange(int(R * 0.3)) / R
save('pickup.wav', np.sin(2 * np.pi * np.where(t < 0.1, 660, np.where(t < 0.2, 880, 1320)) * t) * 0.5 * env(len(t), r=0.2))

# music: 32 s at 120 bpm, A minor, bass + arpeggio + drums
bpm = 120; beat = 60 / bpm; L = int(R * 32)
mus = np.zeros((L, 2))
def note(f): return 440 * 2 ** ((f - 69) / 12)
chords = [(57, 60, 64), (53, 57, 60), (48, 52, 55), (55, 59, 62)]     # Am F C G
step = beat / 4
for i in range(int(32 / step)):
    c = chords[(i // 16) % 4]; t0 = int(i * step * R); n = int(step * R)
    tt = np.arange(n) / R
    f = note(c[i % 3] + 12 * ((i // 3) % 2))
    arp = np.sign(np.sin(2 * np.pi * f * tt)) * 0.12 * np.exp(-tt / 0.08)
    mus[t0:t0 + n, 0] += arp; mus[t0:t0 + n, 1] += arp * 0.6
    if i % 2 == 0:
        fb = note(c[0] - 12)
        bass = (2 * ((tt * fb) % 1) - 1) * 0.22 * np.exp(-tt / 0.2)
        mus[t0:t0 + n] += bass[:, None]
    if i % 4 == 0:                                                     # kick
        k = np.sin(2 * np.pi * np.cumsum(120 * np.exp(-tt * 30) + 45) / R) * 0.5 * np.exp(-tt / 0.1)
        mus[t0:t0 + n] += k[:, None]
    if i % 8 == 4:                                                     # snare
        sn = rng.standard_normal(n) * 0.25 * np.exp(-tt / 0.06)
        mus[t0:t0 + n] += sn[:, None]
    if i % 2 == 1:                                                     # hat
        hh = rng.standard_normal(n) * 0.06 * np.exp(-tt / 0.015)
        mus[t0:t0 + n, 1] += hh; mus[t0:t0 + n, 0] += hh * 0.5
save('music.wav', mus * 0.9)

# ---------------------------------------------------------------- video
# a flight through a star field (rendered here, encoded by ffmpeg)
N = 32 * 25
st = rng.uniform(-1, 1, (900, 3)); st[:, 2] = rng.uniform(0.05, 1, 900)
p = subprocess.Popen(['ffmpeg', '-y', '-v', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', '352x288',
                      '-r', '25', '-i', '-', '-c:v', 'libx264', '-crf', '16', '-pix_fmt', 'yuv420p', 'flight.mp4'],
                     stdin=subprocess.PIPE)
for k in range(N):
    img = np.zeros((288, 352, 3), np.float32)
    yy = np.arange(288)[:, None] / 288
    img[:, :, 2] = 30 + 40 * yy; img[:, :, 0] = 8 + 20 * yy
    st[:, 2] -= 0.012
    gone = st[:, 2] <= 0.02
    st[gone] = np.c_[rng.uniform(-1, 1, (gone.sum(), 2)), np.ones(gone.sum())]
    sx = (176 + st[:, 0] / st[:, 2] * 120).astype(int); sy = (144 + st[:, 1] / st[:, 2] * 120).astype(int)
    b = np.clip(1.2 - st[:, 2], 0.2, 1) * 255
    ok = (sx >= 1) & (sx < 351) & (sy >= 1) & (sy < 287)
    for dx, dy in ((0, 0), (1, 0), (0, 1)):
        img[sy[ok] + dy, sx[ok] + dx] = np.maximum(img[sy[ok] + dy, sx[ok] + dx], b[ok, None] * (1 if dx + dy == 0 else 0.6))
    # a planet drifting past
    cx, cy, r = 352 - k * 0.5, 210 + k * 0.05, 70
    yy2, xx2 = np.ogrid[:288, :352]
    m = (xx2 - cx) ** 2 + (yy2 - cy) ** 2 < r * r
    shade = np.clip(1 - ((xx2 - cx + 30) ** 2 + (yy2 - cy + 30) ** 2) / (2.2 * r * r), 0.15, 1)
    img[m] = (np.array([170, 100, 70]) * shade[..., None])[m]
    p.stdin.write(np.clip(img, 0, 255).astype(np.uint8).tobytes())
p.stdin.close(); p.wait()
print('made title.png space.png sprites.png laser.wav boom.wav pickup.wav music.wav flight.mp4')
