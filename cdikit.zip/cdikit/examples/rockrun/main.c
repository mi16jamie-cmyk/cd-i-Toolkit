/* Rock Run - the CD-i toolkit's example game
 *
 * Steer the ship with the controller, button 1 fires. Shoot the rocks
 * before they reach you; three hits and the game is over.
 *
 * It shows every part of the library:
 *   - pictures and sprites from a mkgfx.py bank (GFX.BIN), text
 *   - sound effects from a mksfx.py bank (SFX.BIN)
 *   - title music as an ADPCM stream (MUSIC.RTF): plays on any CD-i
 *   - with the Digital Video Cartridge: the game runs over an MPEG video
 *     with MPEG music (FLIGHT.RTF); plane A is see-through (colour 0)
 *     wherever nothing is drawn. Without it: a still background.
 */
#include "cdi.h"
#include "gfx.h"                    /* IMG_ numbers (made by mkgfx.py) */
#include "sfx.h"                    /* SFX_ numbers (made by mksfx.py) */

#define MAXROCKS 8
#define MAXSHOTS 4
#define SPR 32
#define HUD_H 24                    /* the score strip: sprites stay below it */

static struct gfx_bank *gfx;
static const struct gfx_image *img[IMG_COUNT];
static int mpeg;                    /* the cartridge is there */

/* the text colours, set after the bank's colours */
#define C_WHITE  (GFX_COLOURS + 1)
#define C_YELLOW (GFX_COLOURS + 2)
#define C_SHADOW (GFX_COLOURS + 3)

static u32 seed = 12345;
static int rnd(int n) { seed = seed * 1103515245u + 12345u; return (int)((seed >> 16) % (u32)n); }

/* text that stays (labels: drawn only when it changes), with a shadow:
 * two label slots, the shadow's and the text's */
static void label(int slot, int x, int y, const char *s, u8 c, int scale)
{
    gfx_label(slot, x + scale, y + scale, s, C_SHADOW, scale);
    gfx_label(slot + 1, x, y, s, c, scale);
}
static void centre(int slot, int y, const char *s, u8 c, int scale)
{
    label(slot, (GFX_W - gfx_text_width(s, scale)) / 2, y, s, c, scale);
}
static void labels_off(void)
{
    for (int i = 0; i < 16; i++) gfx_label_clear(i);
}

/* ------------------------------------------------------------------ title */
static void title(void)
{
    stream_play("MUSIC.RTF", STREAM_ADPCM);
    gfx_background(img[IMG_TITLE], 0);
    u32 t0 = cdi_ticks();
    for (;;) {
        pad_read();
        if (pad_pressed() & (PAD_B1 | PAD_B2)) break;
        if (stream_ended()) stream_play("MUSIC.RTF", STREAM_ADPCM);    /* again */
        gfx_restore();
        centre(0, 80, "ROCK RUN", C_YELLOW, 6);
        centre(2, 150, "made with the CD-i toolkit", C_WHITE, 1);
        centre(4, 170, mpeg ? "MPEG cartridge: video background on" : "no MPEG cartridge: still background",
               C_WHITE, 1);
        int on = ((cdi_ticks() - t0) * 2 / cdi_tick_rate()) & 1;     /* blinks twice a second */
        centre(6, 220, on ? "PRESS BUTTON 1" : "", C_YELLOW, 2);
        gfx_swap();
    }
    labels_off();
    stream_stop();
}

/* ------------------------------------------------------------------ game */
struct obj { s16 x, y, dy, kind, t; };     /* kind 0 = none */

static void game(void)
{
    struct obj rock[MAXROCKS], shot[MAXSHOTS];
    int sx = (GFX_W - SPR) / 2, sy = GFX_H - SPR - 16;
    int lives = 3, score = 0, next_bonus = 500, hurt = 0, frame = 0, over = 0;
    u32 fps_t = cdi_ticks(); int fps_n = 0;
    char b[16];
    for (int i = 0; i < MAXROCKS; i++) rock[i].kind = 0;
    for (int i = 0; i < MAXSHOTS; i++) shot[i].kind = 0;

    /* the background: see-through over the video, or the still picture;
     * sprites are cut off below the score strip, so they never cross the
     * score (which would have to be drawn again) */
    gfx_background(mpeg ? 0 : img[IMG_SPACE], 0);
    gfx_window(0, HUD_H, GFX_W, GFX_H - HUD_H);
    if (mpeg) stream_play("FLIGHT.RTF", STREAM_MPEG);
    for (;;) {
        u16 pad = pad_read(), hit = pad_pressed();
        if (mpeg) {
            stream_feed();
            if (stream_ended()) stream_play("FLIGHT.RTF", STREAM_MPEG);
        }
        if (!over) {
            /* the ship */
            if (pad & PAD_LEFT) sx -= 6;
            if (pad & PAD_RIGHT) sx += 6;
            if (pad & PAD_UP) sy -= 4;
            if (pad & PAD_DOWN) sy += 4;
            if (sx < 0) sx = 0;
            if (sx > GFX_W - SPR) sx = GFX_W - SPR;
            if (sy < 120) sy = 120;
            if (sy > GFX_H - SPR) sy = GFX_H - SPR;
            if (hit & PAD_B1)
                for (int i = 0; i < MAXSHOTS; i++)
                    if (!shot[i].kind) {
                        shot[i].kind = 1; shot[i].x = sx; shot[i].y = sy - 16;
                        sfx_play(SFX_LASER);
                        break;
                    }
            /* new rocks, faster as the score goes up */
            if (rnd(100) < 6 + score / 200)
                for (int i = 0; i < MAXROCKS; i++)
                    if (!rock[i].kind) {
                        rock[i].kind = 1 + rnd(2); rock[i].x = rnd(GFX_W - SPR); rock[i].y = HUD_H - SPR;
                        rock[i].dy = 2 + rnd(3) + score / 400; rock[i].t = 0;
                        break;
                    }
        } else if (hit & PAD_B1) break;
        /* move everything */
        for (int i = 0; i < MAXSHOTS; i++)
            if (shot[i].kind && (shot[i].y -= 12) < HUD_H - SPR) shot[i].kind = 0;
        for (int i = 0; i < MAXROCKS; i++) {
            struct obj *r = &rock[i];
            if (!r->kind) continue;
            if (r->kind == 9) { if (++r->t >= 8) r->kind = 0; continue; }   /* exploding */
            r->y += r->dy;
            if (r->y > GFX_H) { r->kind = 0; continue; }
            for (int k = 0; k < MAXSHOTS; k++) {
                struct obj *s = &shot[k];
                if (s->kind && s->x + 18 > r->x + 4 && s->x + 14 < r->x + 28 && s->y + 6 < r->y + 28 && s->y + 26 > r->y + 4) {
                    s->kind = 0; r->kind = 9; r->t = 0;
                    score += 10;
                    sfx_play(SFX_BOOM);
                    if (score >= next_bonus) { next_bonus += 500; lives++; sfx_play(SFX_PICKUP); }
                    break;
                }
            }
            if (r->kind != 9 && !over && !hurt &&
                r->x + 26 > sx + 6 && r->x + 6 < sx + 26 && r->y + 26 > sy + 6 && r->y + 6 < sy + 26) {
                r->kind = 9; r->t = 0; hurt = 40;
                sfx_play(SFX_BOOM);
                if (--lives <= 0) over = 1;
            }
        }
        if (hurt) hurt--;

        /* draw: the last frame's sprites away, this frame's in */
        gfx_restore();
        for (int i = 0; i < MAXROCKS; i++)
            if (rock[i].kind == 9) gfx_draw(img[IMG_SPRITES_4 + rock[i].t / 2], rock[i].x, rock[i].y);
            else if (rock[i].kind) gfx_draw(img[IMG_SPRITES_0 + rock[i].kind], rock[i].x, rock[i].y);
        for (int i = 0; i < MAXSHOTS; i++)
            if (shot[i].kind) gfx_draw(img[IMG_SPRITES_3], shot[i].x, shot[i].y);
        if (!over && !(hurt & 2)) gfx_draw(img[IMG_SPRITES_0], sx, sy);
        label(0, 8, 6, "SCORE", C_WHITE, 2);
        label(2, 74, 6, fmt_num(b, score, 5), C_YELLOW, 2);
        label(4, GFX_W - 100, 6, "LIVES", C_WHITE, 2);
        label(6, GFX_W - 34, 6, fmt_num(b, lives, 0), C_YELLOW, 2);
        if (over) {
            centre(8, 110, "GAME OVER", C_YELLOW, 4);
            centre(10, 160, (frame >> 3) & 1 ? "PRESS BUTTON 1" : "", C_WHITE, 2);
        }
        if (++fps_n == 25) {        /* frames a second, at the bottom */
            u32 now = cdi_ticks();
            gfx_label(12, 4, GFX_H - 10, fmt_num(b, (s32)(25 * cdi_tick_rate() / (now - fps_t + 1)), 0), C_WHITE, 1);
            fps_t = now; fps_n = 0;
        }
        gfx_swap();
        frame++;
    }
    labels_off();
    gfx_window(0, 0, GFX_W, GFX_H);
    if (mpeg) stream_stop();
}

int main(void)
{
    cdi_catch_crashes();            /* (debugging: a crash shows where) */
    if (gfx_init()) return 1;
    gfx = gfx_load_bank("GFX.BIN");
    if (!gfx) return 2;
    for (int i = 0; i < IMG_COUNT; i++) img[i] = gfx_bank_image(gfx, i);
    gfx_use_palette(gfx);
    static const u32 text_colours[3] = { 0xFFFFFF, 0xFFD000, 0x101010 };
    gfx_palette(text_colours, C_WHITE, 3);
    sfx_load("SFX.BIN");
    mpeg = cdi_has_mpeg();
    for (;;) {
        title();
        seed += cdi_ticks();
        game();
    }
}
