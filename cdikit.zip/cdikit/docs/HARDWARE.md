# CD-i hardware notes

What the library relies on, as worked out while porting MegaRace: tested in MAME (cdimono1 with the VMPEG Digital Video Cartridge), not yet on a real player. Addresses are for the CD-i 210-family ("mono") players that MAME's cdimono1 emulates.

## Supervisor mode

There's no MMU: a program can read and write the vector table and most hardware registers directly. The 68070's on-chip peripherals (DMA, at `0x80004000`) are supervisor-only, so `crt0.s` installs a **line-A handler** (vector `0x28`). An instruction word `0xA00n` in the program then runs a small routine in supervisor mode:

| Word | Routine |
|---|---|
| `0xA000` | Feed the MPEG decoders |
| `0xA001` | Reset the MPEG decoders |
| `0xA002` | Probe for the cartridge |

Registers are kept across the call. The handler returns past the word. On the 68070 the stacked PC is at offset 2 of the exception frame.

## Display (MCD212)

- **Display control program.** Every field, channel 1 runs an "ICA" list whose address is at `0x400` (both words of `0x400`/`0x404`, one per field parity), in instruction form `0x40000000 | (address & 0x7FFFF)`. The library's list:

  | Instruction | Meaning |
  |---|---|
  | `C0040001` | Image coding: external video as backdrop, plane A CLUT8, plane B off |
  | `C1000001` | Transparency: plane A see-through on the colour key |
  | `C4xxxxxx` | The key colour: `FC00FC`, which is colour 0 |
  | `DB00003F` | Plane A weight |
  | `4xxxxxxx` | Continue at the "path list" |

  The path list holds the colours, then `RELOAD VSR` (`0x50000000 | (address & 0x3FFFFF)`), the picture to show, then STOP (`0`).
- **Colours:** 4 banks of 64. `C300000b` selects bank b; then `0x80000000 | (i << 24) | 0xRRGGBB`, with 6 bits per component (low 2 bits ignored).
- **DCR1** (`0x4FFFF2`): `| 0x8200` turns the display and ICA on. `& ~0x0100` turns DCA (per-line changes) off.
- **CSR1R** (`0x4FFFF1`, read): bit 5 = field parity, which flips after a field's last line (50 times a second). Bit 7 = display active. `gfx_swap` writes the new VSR, then waits for bit 5 to flip: the old picture is then free to draw into.
- **Memory:** display memory must come from `F$SRqCMem` with type `0x80` (video bank 1). The pictures are 384 × 280 bytes each.

## Controller

`/ptr` (pointer manager), via `I$GetStt`/`I$SetStt` code `SS_PT` (`0x59`):

- `PT_Coord` (0) returns buttons in d0 (bit 0 = button 1, bit 1 = button 2) and x:y in d1.
- `PT_Pos` (3) moves the pointer to d3 = x:y.

The library centres the pointer at (360, 240) after each movement.

## Sound effects (audio processor, `/ap`)

`I$SetStt` code `SS_SM` (`0x3B`) on a path to `/ap`, opened read+write:

| d2 | Call | Arguments | Result |
|---|---|---|---|
| 0 | `SM_Creat` | d3 = type (4 = level C mono), d4 = sound groups (18 per 2304-byte sector) | d0 = id, a0 = its buffer; fill it with ADPCM sound groups |
| 1 | `SM_Out` | d3 = id, a0 = status block | Plays it |
| 2 | `SM_Off` | d3 = id | Stops it |

## Real-time play (CD drive)

`I$SetStt` code `SS_PLAY` (`0x2D`) on an open file path, a0 = play control block (PCB):

| Offset | Field | |
|---|---|---|
| 0 | `PCB_Stat` | w |
| 2 | `PCB_Sig` | w: signal sent when the play ends (the library asks for none; it polls) |
| 4 | `PCB_Rec` | l: records to play (`0x7FFFFFFF` = all) |
| 8 | `PCB_Chan` | l: channel mask (1 = channel 0) |
| 12 | `PCB_AChan` | w: audio channel mask; ADPCM sectors on those channels go straight to the audio processor |
| 14 | `PCB_Video` | l |
| 18 | `PCB_Audio` | l |
| 22 | `PCB_Data` | l: pointer to a pointer to the first play control list (PCL) cell |

Each PCL cell is 28 bytes. The driver sets bit 0 of `PCL_Ctrl` when the cell's buffer is filled, and sends the cell's signal.

| Offset | Field | |
|---|---|---|
| 0 | `PCL_Ctrl` | |
| 4 | `PCL_Sig` | w: signal for each filled cell (the library asks for none) |
| 6 | `PCL_Nxt` | next cell |
| 10 | `PCL_Buf` | buffer |
| 14 | `PCL_BufSz` | in sectors |
| 18 | `PCL_Err` | |
| 24 | `PCL_Cnt` | |

The library keeps a ring of 32 one-sector cells and empties it from its own loop. `SS_Abort` (`0x31`) stops the play. (A program that wants signals sets an intercept with `F$Icpt`; the handler ends with `F$RTE`.)

## Digital Video Cartridge (MPEG)

Video decoder registers (word unless noted):

| Address | Register | |
|---|---|---|
| `E04058` | (long) time code | |
| `E0405E` | status | bit 5 = ready for a sector |
| `E04060` | interrupt enable | |
| `E04074` | (long) picture position on screen | y << 16 \| x |
| `E04078` | (long) decoder window | lines << 16 \| width |
| `E0407C` | (long) window offset | |
| `E040A4` | pictures decoded | |
| `E040C0` | system command | |
| `E040C2` | video command | |

Reset sequence: system command `2000`, `0100`, `1000`, then window and position, then video command `0008`. Once 5 or more pictures are decoded, system command `0008` and video command `0420` start the picture.

Audio decoder registers:

| Address | Register | |
|---|---|---|
| `E03000` | command | `0001` = stop and empty; `8000` = take a DMA'd sector |
| `E03008` | stream | 0 = MPEG audio packets `0xC0` |
| `E0301C` | interrupt enable | |

**Feeding:** each 2324-byte MPEG pack goes by 68070 DMA channel 1:

| Register | Value |
|---|---|
| `CSR` (`80004040`) | `FF` (clear) |
| `MAC` (`8000404C`) | the buffer |
| `MTC` (`8000404A`) | 1162 words |
| `SCR` | `04` |
| `OCR` | `12` |
| `DCR` | `30` |
| `CCR` | `80` (go) |

Then command `8000` goes to the video decoder (`E040C0`), or to the audio decoder (`E03000`) if the pack's stream id, after the pack header and any system header, is `0xC0`–`0xDF`. Wait for CSR bit 7 (done).

**Detecting the cartridge:** with no cartridge, reading `E0405E` gives a bus error; `crt0.s` catches it.

## Discs

`mkcdi.py` writes an ISO 9660 volume with CD-ROM XA extensions:

- Mode 2 sectors; Form 1 for ordinary files.
- System identifier `CD-RTOS CD-BRIDGE`.
- Application identifier = the boot program's file name. The player's launcher runs it.

Real-time files are Form 2 sectors with a subheader of file 1, channel, submode and coding:

| Submode | Sector |
|---|---|
| `DATA \| FORM2 \| RT` | MPEG pack |
| `AUDIO \| FORM2 \| RT` | ADPCM sound, with the coding byte: +1 = stereo, +4 = level C |
| channel 31 | Empty |

The last sector has `EOR | EOF`.
