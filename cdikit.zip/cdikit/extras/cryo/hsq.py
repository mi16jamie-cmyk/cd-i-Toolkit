def unhsq(src, i=0, limit=None):
    out=bytearray(); q=0; n=0
    def bit():
        nonlocal q,n,i
        if n==0:
            q=src[i]|src[i+1]<<8; i+=2; n=16
        b=q&1; q>>=1; n-=1; return b
    while True:
        if bit():
            out.append(src[i]); i+=1
        else:
            if bit():
                w=src[i]|src[i+1]<<8; i+=2
                c=w&7; off=(w>>3)-8192
                if c==0:
                    c=src[i]; i+=1
                    if c==0: break
                c+=2
            else:
                c=bit()*2; c+=bit(); c+=2
                off=src[i]-256; i+=1
            for _ in range(c): out.append(out[off])
        if limit and len(out)>=limit: break
    return bytes(out), i
def hsqfile(d):
    size=d[0]|d[1]<<8|d[2]<<16
    assert sum(d[:6])&0xff==0xab, 'bad hsq header'
    o,_=unhsq(d,6); return o[:size] if size else o, size
