// render.cpp IN.HSQ OUT.raw SECONDS [RATE]: a HERAD song (Cryo AdLib music)
// through the Nuked OPL3 emulator, as 16-bit stereo; the song loops
#include <cstdio>
#include <cstdlib>
#include "herad.h"
#include "nemuopl.h"
#include "fprovide.h"
#include "adplug.h"
CAdPlugDatabase *CAdPlug::database = 0;
int main(int argc, char **argv)
{
    if (argc < 4) return 1;
    int rate = argc > 4 ? atoi(argv[4]) : 37800;
    double secs = atof(argv[3]);
    CNemuopl opl(rate);
    CheradPlayer pl(&opl);
    CProvider_Filesystem fp;
    if (!pl.load(argv[1], fp)) { fprintf(stderr, "can't load %s\n", argv[1]); return 1; }
    pl.rewind(0);
    FILE *o = fopen(argv[2], "wb");
    long total = (long)(secs * rate), done = 0;
    short buf[2 * 4096];
    double acc = 0;
    int ends = 0;
    while (done < total) {
        double per = rate / pl.getrefresh();
        acc += per;
        long n = (long)acc; acc -= n;
        while (n > 0 && done < total) {
            long k = n > 4096 ? 4096 : n;
            if (k > total - done) k = total - done;
            opl.update(buf, k);
            fwrite(buf, 4, k, o);
            n -= k; done += k;
        }
        if (!pl.update()) { ends++; if (ends == 1) fprintf(stderr, "song length %.1f s\n", (double)done / rate); }
    }
    fclose(o);
    return 0;
}
