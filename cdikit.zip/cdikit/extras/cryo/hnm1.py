import struct
def dec173(d, i, end, opt=None):
    opt=opt if isinstance(opt,dict) else {}
    fs,cbs,fl,salt=struct.unpack('<HHBB',d[i:i+6]); i+=6
    x=y=0
    if not fl&4: x,y=struct.unpack('<HH',d[i:i+4]); i+=4
    base=128 if fl&64 else 0; longm=bool(fl&128)
    st={'i':i,'pend':None}
    def nib(which):
        if opt.get('sep') and which=='r': key='pr'
        else: key='pend'
        if st.get(key) is None:
            b=d[st['i']]; st['i']+=1
            if opt.get('lofirst'): st[key]=b>>4; return b&15
            st[key]=b&15; return b>>4
        v=st[key]; st[key]=None; return v
    cb=bytearray()
    while len(cb)<cbs:
        t=d[st['i']]; st['i']+=1
        if t&0x80:
            tmp=nib('c')
            off=((t&0x7f)<<1)|(tmp&1); c=(tmp>>1)+2
            for _ in range(c): cb.append(cb[-off-1])
        else: cb.append(t+base if t else 0)
    st['pend']=None
    cbp=0; out=bytearray(); q=0; n=0
    def bit():
        nonlocal q,n
        if n==0:
            j=st['i']; q=d[j]|d[j+1]<<8; st['i']+=2; n=16
        b=(q>>15)&1; q=(q<<1)&0xffff; n-=1; return b
    def run():
        l=nib('r')
        if l==0: l=d[st['i']]+opt.get('add',16); st['i']+=1
        return l+opt.get('r4',4)
    while len(out)<fs:
        while not bit():
            out.append(cb[cbp]); cbp+=1
        p=cb[cbp]; cbp+=1
        if longm:
            if not bit(): c=run()
            elif not bit(): c=2
            elif not bit(): c=3
            else: c=4
        else:
            if not bit(): c=2
            elif not bit(): c=3
            elif not bit(): c=4
            else: c=run()
        out.extend([p]*c)
    return out[:fs],(x,y),st['i'],cbp,len(cb),fl
