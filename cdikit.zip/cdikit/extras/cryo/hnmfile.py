import struct,sys
sys.path.insert(0,__file__.rsplit('/',1)[0])
from hnm1 import dec173
from hnm_ad import dec as dec_ad
from hsq import unhsq
class HNM:
    def __init__(s,path):
        d=s.d=open(path,'rb').read()
        hs=struct.unpack('<H',d[:2])[0]; i=2; s.pal=[(0,0,0)]*256
        i=s.readpal(i)
        while d[i]==0xff and i<hs: i+=1
        s.offs=[struct.unpack('<I',d[j:j+4])[0]+hs for j in range(i,hs,4)]
        # (B64's table is wrong; each frame's own size field is right: when
        # following those ends exactly at the end of the file, use them)
        p=s.offs[0]; w=[]
        while p+2<=len(d):
            fs=struct.unpack('<H',d[p:p+2])[0]
            if fs==0: break
            w.append(p); p+=fs
        if p==len(d) and w!=s.offs[:-1]: s.offs=w+[p]
        s.n=len(s.offs)-1; s.fb=bytearray(320*200)
    def readpal(s,i):
        d=s.d
        while True:
            st,c=d[i],d[i+1]; i+=2
            if st==0xff and c==0xff: return i
            c=c or 256
            for k in range(c): s.pal[(st+k)&255]=tuple(min(255,x*4) for x in d[i+3*k:i+3*k+3])
            i+=3*c
    def frame(s,k):
        d=s.d;o=s.offs[k];fs=struct.unpack('<H',d[o:o+2])[0];p=o+2;ch={}
        while p<o+fs:
            tag=d[p:p+2]
            if tag.isalpha() and tag.islower():
                cs=struct.unpack('<H',d[p+2:p+4])[0]; ch[tag.decode()]=d[p+4:p+cs]
                if tag==b'pl': s.readpal(p+4)
                p+=cs
            else: break
        info=None
        if p<o+fs:
            hdr=struct.unpack('<I',d[p:p+4])[0]; w=hdr&0x1ff; h=(hdr>>16)&0xff; mode=hdr>>24
            if w and h:
                cs=sum(d[p+4:p+10])&0xff
                if cs==0xad:
                    out,x,y,j=dec_ad(d,p+4)
                elif cs==0xab and hdr&0x8000:
                    # (CREDIT) x, y, then run-length rows (as the sprite
                    # banks) over the last full picture: scrolling text
                    raw,_=unhsq(d,p+10)
                    x,y=struct.unpack('<HH',raw[:4]); q=4; out=bytearray()
                    while q<len(raw) and len(out)<w*h:
                        c=raw[q]; q+=1
                        if c&0x80: out+=bytes([raw[q]])*(257-c); q+=1
                        else: out+=raw[q:q+c+1]; q+=c+1
                    if getattr(s,'base',None) is not None: s.fb[:]=s.base
                elif cs==0xab:
                    out,_=unhsq(d,p+10); x=y=0
                else: return ch,None              # (a third method, 0x74CC: not needed)
                ww=w
                for r in range(len(out)//ww):
                    for c in range(ww):
                        px=out[r*ww+c]
                        if mode==0xff and px==0: continue
                        if (y+r)<200 and x+c<320: s.fb[(y+r)*320+x+c]=px
                info=(w,h,mode,x,y,cs)
                if w==320 and h>=152 and mode!=0xff: s.base=bytes(s.fb)
        return ch,info
    def img(s,h=200):
        from PIL import Image
        im=Image.frombytes('P',(320,h),bytes(s.fb[:320*h])); im.putpalette([v for c in s.pal for v in c]); return im
