#!/usr/bin/env python3
"""hnm2video.py IN.HNM OUT.mp4 - a Cryo HNM video (MegaRace, and other Cryo
games of 1993-95 using the same formats) as an ordinary video file with its
sound, ready for mkstream.py:

    python3 hnm2video.py LANCE.HNM lance.mp4
    python3 ../../tools/mkstream.py LANCE.RTF --mpeg --adpcm --video lance.mp4

The clip runs at the rate its sound needs (about 12.6 pictures a second for
MegaRace's clips; 12.5 when there's no sound, or --fps). Pictures are 320 x
200 (VGA), scaled by mkstream.py. With --frames DIR the pictures are also
saved as PNGs.
"""
import sys, os, struct, argparse, subprocess, tempfile, wave
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hnmfile import HNM

ap = argparse.ArgumentParser(description=__doc__.split('\n')[0])
ap.add_argument('hnm'); ap.add_argument('out')
ap.add_argument('--fps', type=float)
ap.add_argument('--frames')
a = ap.parse_args()

h = HNM(a.hnm)
snd = bytearray(); rate = 11111
for k in range(h.n):                # the 'sd' chunks: 8-bit unsigned sound (VOC in the first)
    d = h.d; o = h.offs[k]; e = h.offs[k + 1]; p = o + 2
    while p < e:
        tag = d[p:p + 2]
        if not (tag.isalpha() and tag.islower()): break
        cs = struct.unpack('<H', d[p + 2:p + 4])[0]
        if tag == b'sd':
            b = d[p + 4:p + cs]
            if b[:19] == b'Creative Voice File':
                q = struct.unpack('<H', b[20:22])[0]
                if b[q] == 1: rate = 1000000 // (256 - b[q + 4])
                b = b[q + 6:]
            snd += b
        p += cs
fps = a.fps or (h.n * rate / len(snd) if snd else 12.5)
tmp = tempfile.mkdtemp()
if a.frames: os.makedirs(a.frames, exist_ok=True)
cmd = ['ffmpeg', '-y', '-v', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', '320x200', '-r', '%.4f' % fps, '-i', '-']
if snd:
    wav = os.path.join(tmp, 's.wav')
    with wave.open(wav, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(1); w.setframerate(rate); w.writeframes(bytes(snd))
    cmd += ['-i', wav, '-c:a', 'aac', '-b:a', '192k']
cmd += ['-c:v', 'libx264', '-crf', '14', '-pix_fmt', 'yuv420p', a.out]
ff = subprocess.Popen(cmd, stdin=subprocess.PIPE)
for k in range(h.n):
    try: h.frame(k)
    except Exception: pass          # (a frame it can't decode: the last picture again)
    im = h.img(200).convert('RGB')
    if a.frames: im.save(os.path.join(a.frames, '%05d.png' % k))
    ff.stdin.write(im.tobytes())
ff.stdin.close(); ff.wait()
print('%s: %d pictures at %.2f a second, %.1f s of sound' % (a.out, h.n, fps, len(snd) / rate))
