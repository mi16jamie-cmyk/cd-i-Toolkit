# Cryo extras

Decoders for the file formats of Cryo Interactive's early-1990s PC games, written while porting MegaRace (1993) to the CD-i. Other Cryo games of the period, such as Dune (1992), Lost Eden (1995) and Commander Blood (1994), use the same or closely related formats. They're here because they are the first step of porting such a game: getting its pictures, video and music out in ordinary formats the toolkit's tools take.

| File | What it does |
|---|---|
| `hnm2video.py` | An HNM video (with its sound) to an MP4, for `mkstream.py` |
| `hnmfile.py` | Reads HNM files: frames, palettes, sound chunks (`HNM(path)`, `.frame(k)`, `.img()`) |
| `hnm1.py`, `hnm_ad.py` | The two picture compression methods (0xAB/HSQ and 0xAD) |
| `hsq.py` | HSQ decompression (Cryo's LZ format, used for most data files: `hsqfile(bytes)`) |
| `herad_render.cpp` | Renders a HERAD song (Cryo's AdLib music, `.HSQ` in MegaRace) to a WAV-able raw file |

## Video

```sh
python3 hnm2video.py INTRO.HNM intro.mp4
python3 ../../tools/mkstream.py INTRO.RTF --mpeg --adpcm --video intro.mp4
```

`--frames DIR` also saves every picture as a PNG, useful for stills (`mkgfx.py` takes them). One MegaRace clip (`B64.HNM`) has a wrong frame table; `hnmfile.py` notices and follows the frames' own sizes.

## Music

HERAD songs need [AdPlug](https://github.com/adplug/adplug) (LGPL), which has a HERAD player and the Nuked OPL3 emulator. Build AdPlug, then:

```sh
g++ -O2 -I/path/to/adplug/src -I/path/to/libbinio/include herad_render.cpp \
    /path/to/adplug/build/libadplug.a /path/to/libbinio/build/libbinio.a -o herad_render
./herad_render NEWSAN.HSQ newsan.raw 240 44100     # 240 seconds, 44.1 kHz, looped
ffmpeg -f s16le -ar 44100 -ac 2 -i newsan.raw newsan.wav
```

The WAV then goes to `mkstream.py` like any other music.

## Legal note

These decoders were worked out by studying the games. Using them on games you own, for your own ports, is the intended use. If you publish a port, publish your code and tools, not the game's data: people build the disc from their own copy (`tools/mkpatch.py` helps with that).
