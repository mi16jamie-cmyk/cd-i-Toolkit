# hnm_ad.py: the HNM 'method 0xAD' picture decoder, a literal transcription
# of RACEPRG.EXE 0xEDB4 (codebook at 0xEF5C). dec(d, i) -> (pixels, x, y, end)
# hnm1.dec173 gets a few frames of the Lance Boyle clips wrong; this doesn't.
import struct
def dec(d, i):
    hdr=d[i:i+6]; fs,cbs=struct.unpack('<HH',hdr[:4]); fl=hdr[4]
    si=i+6
    out=bytearray(fs+8)
    di=0
    if not fl&4: out[0:4]=d[si:si+4]; si+=4; di=4
    base=(fl&0x40)*2 & 0xff
    bp=di+fs
    # codebook at bp-cbs .. bp, decoded from stream bx=si
    bx=si; cdi=bp-cbs
    # 0xEF5C
    state=0; dl=0
    while True:
        al=d[bx]
        if al&0x80:
            if state==0:
                cl=d[bx+1]; dl=cl
                off=((al<<1)&0xff)|((cl>>4)&1); cnt=(cl>>5)+2; bx+=2; state=1
            else:
                cl=dl&0xf
                off=((al<<1)&0xff)|(cl&1); cnt=(cl>>1)+2; bx+=1; state=0
            src=cdi-(off+1)
            for _ in range(cnt): out[cdi]=out[src]; cdi+=1; src+=1
        else:
            out[cdi]=(al+base)&0xff if al else 0; cdi+=1; bx+=1
        if cdi>=bp: break
    si=bp-cbs
    # main
    cx=0; dx=0; cf=0
    def getbit():
        nonlocal dx,bx
        dx=(dx<<1)&0x1ffff; c=dx>>16; dx&=0xffff
        if dx==0:
            w=d[bx]|d[bx+1]<<8; bx+=2
            v=(w<<1)|1; c=v>>16; dx=v&0xffff
        return c
    longm=fl&0x80
    # first word load: mov dx,[bx]; adc dx,dx with CF=1
    w=d[bx]|d[bx+1]<<8; bx+=2; v=(w<<1)|1; first=v>>16; dx=v&0xffff
    b=first
    while True:
        # b is the next flag bit
        while not b:
            out[di]=out[si]; di+=1; si+=1
            b=getbit()
        p=out[si]; si+=1
        if not longm:
            if not getbit(): c=2
            elif not getbit(): c=3
            elif not getbit(): c=4
            else:
                if di>=bp: break
                c=None
        else:
            if not getbit(): 
                c=None
            elif not getbit(): c=2
            elif not getbit(): c=3
            else:
                if di>=bp: break
                c=4
        if c is None:
            if cx<4:
                cl=d[bx]; h=cl>>4
                if h:
                    c=h+4; bx+=1; cx=(cl&0xf)+4
                else:
                    c=d[bx+1]+0x14; bx+=2; cx=(cl&0xf)+4
            elif cx==4:
                c=d[bx]+0x14; bx+=1; cx=0
            else:
                c=cx; cx=0
        for _ in range(c): out[di]=p; di+=1
        b=getbit()
    x=y=0
    if not fl&4: x,y=struct.unpack('<HH',bytes(out[0:4]))
    start=0 if fl&4 else 4
    return bytes(out[start:start+fs]), x, y, bx
