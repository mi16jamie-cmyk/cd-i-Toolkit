-- autorun.lua - drive a CD-i program in MAME for testing, without a person
--
--   mame cdimono1 [-dvc vmpeg] -cdrom game.cue -autoboot_script autorun.lua
--
-- Environment variables (times in emulated seconds):
--   START   when to press button 1 on the player's menu to start the disc
--           (default 20; the CD-i shell takes ~20 s to come up)
--   INPUT   what to press, "time:duration:what;..." with what one of
--           b1 b2 b3 left right up down (e.g. "30:2:right;33:0.2:b1")
--   SHOTS   when to save screenshots, "time,time,..."; or SHOTEVERY with
--           SHOTSTART for one every SHOTEVERY seconds
--   TEND    when to quit (default 60)
-- Screenshots go to MAME's snapshot directory (-snapshot_directory).
local P = manager.machine.ioport.ports
local btn = { b1 = P[":MOUSEBTN"].fields["Button 1"], b2 = P[":MOUSEBTN"].fields["Button 2"],
              b3 = P[":MOUSEBTN"].fields["Button 3"] }
local mx, my = P[":MOUSEX"].fields["Mouse X"], P[":MOUSEY"].fields["Mouse Y"]
local START = tonumber(os.getenv("START") or "20")
local TEND = tonumber(os.getenv("TEND") or "60")
local SHOTEVERY = tonumber(os.getenv("SHOTEVERY") or "0")
local nextshot = tonumber(os.getenv("SHOTSTART") or "0")
local events, shots = {}, {}
for t, d, w in string.gmatch(os.getenv("INPUT") or "", "([%d%.]+):([%d%.]+):(%a+%d?)") do
  table.insert(events, { t = tonumber(t), d = tonumber(d), w = w })
end
for t in string.gmatch(os.getenv("SHOTS") or "", "([%d%.]+)") do table.insert(shots, tonumber(t)) end
table.sort(shots)
local si = 1
local px, py = 0, 0          -- (MAME takes the mouse value as a position,
local BASE = 4096            --  and ignores values below where it started)
emu.register_frame_done(function()
  local t = manager.machine.time:as_double()
  local on = { b1 = 0, b2 = 0, b3 = 0 }
  local dx, dy = 0, 0
  if t >= START and t < START + 0.3 then on.b1 = 1 end
  for _, e in ipairs(events) do
    if t >= e.t and t < e.t + e.d then
      if on[e.w] then on[e.w] = 1
      elseif e.w == "left" then dx = -8 elseif e.w == "right" then dx = 8
      elseif e.w == "up" then dy = -8 elseif e.w == "down" then dy = 8 end
    end
  end
  for k, f in pairs(btn) do f:set_value(on[k]) end
  px = px + dx; py = py + dy
  if t > 0.5 then mx:set_value(BASE + px); my:set_value(BASE + py) end
  if si <= #shots and t >= shots[si] then si = si + 1; manager.machine.video:snapshot() end
  if SHOTEVERY > 0 and t >= nextshot then nextshot = nextshot + SHOTEVERY; manager.machine.video:snapshot() end
  if t >= TEND then manager.machine:exit() end
end, "autorun")
