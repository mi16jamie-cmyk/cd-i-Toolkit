/* bench - times the library's drawing operations and shows the results */
#include "cdi.h"
void cdi_fill(void *dst, u32 bytes, u32 v);
int main(void)
{
    if (gfx_init()) return 1;
    static const u32 pal[] = { 0, 0xFFFFFF, 0xFFFF00, 0x202040 };
    gfx_palette(pal, 0, 4);
    struct gfx_bank *bk = gfx_load_bank("GFX.BIN");
    if (!bk) return 3;
    const struct gfx_image *ship = gfx_bank_image(bk, 0), *space = gfx_bank_image(bk, 8);
    char b[16];
    u32 r[8]; const char *what[8] = { "fill 107K video x10", "background 384x280 x10", "rock sprite (runs) x100",
        "text 40 ch x10", "ship sprite (runs) x100", "swap x10", "ticks() x1000", "rect 100x40 x100" };
    u32 rate = cdi_tick_rate(), t;
    t = cdi_ticks(); for (int i = 0; i < 10; i++) cdi_fill(gfx_back(), GFX_W * GFX_H, 0x03030303); r[0] = cdi_ticks() - t;
    t = cdi_ticks(); for (int i = 0; i < 10; i++) gfx_draw_opaque(space, 0, 0); r[1] = cdi_ticks() - t;
    t = cdi_ticks(); for (int i = 0; i < 100; i++) gfx_draw(gfx_bank_image(bk, 1), 150, 100); r[2] = cdi_ticks() - t;
    t = cdi_ticks(); for (int i = 0; i < 10; i++) gfx_text(0, 100, "0123456789012345678901234567890123456789", 1, 1); r[3] = cdi_ticks() - t;
    t = cdi_ticks(); for (int i = 0; i < 100; i++) gfx_draw(ship, 100, 100); r[4] = cdi_ticks() - t;
    t = cdi_ticks(); for (int i = 0; i < 10; i++) gfx_swap(); r[5] = cdi_ticks() - t;
    t = cdi_ticks(); for (int i = 0; i < 1000; i++) cdi_ticks(); r[6] = cdi_ticks() - t;
    t = cdi_ticks(); for (int i = 0; i < 100; i++) gfx_rect(10, 10, 100, 40, 2); r[7] = cdi_ticks() - t;
    for (;;) {
        gfx_clear(3);
        gfx_text(10, 10, "ms for:", 1, 2);
        for (int i = 0; i < 8; i++) {
            gfx_text(10, 44 + i * 20, what[i], 1, 1);
            gfx_text(250, 40 + i * 20, fmt_num(b, (s32)(r[i] * 1000 / rate), 0), 2, 2);
        }
        gfx_swap();
    }
}
