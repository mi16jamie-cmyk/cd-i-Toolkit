#!/bin/sh
# build-toolchain.sh - build the CD-i C compiler (toolchaincdi: GNU binutils
# and GCC for OS-9/68000, and elf2mod) from source, for Linux or Windows WSL.
#
#   sh setup/build-toolchain.sh [PREFIX]        (default: ~/cdi-toolchain)
#
# Then add PREFIX/bin to your PATH (the script prints the line to add).
# Takes 15-40 minutes and ~3 GB of disk while building (in WORK, by default
# ~/.cache/cdi-toolchain-build; delete it afterwards). Needs: git, make, a
# C/C++ compiler, bison, flex, texinfo, wget, xz (the script installs them
# with apt on Debian/Ubuntu if it can).
set -e
PREFIX=${1:-$HOME/cdi-toolchain}
WORK=${WORK:-$HOME/.cache/cdi-toolchain-build}
JOBS=$(nproc 2>/dev/null || echo 2)
REPO=https://github.com/cdifan/toolchaincdi

if command -v apt-get >/dev/null 2>&1 && ! [ -f /usr/include/mpc.h ] && [ -z "$GMP_PREFIX" ]; then
    echo "== installing build tools and GCC's libraries (apt)"
    sudo apt-get update
    sudo apt-get install -y build-essential bison flex texinfo wget git xz-utils zlib1g-dev \
        libgmp-dev libmpfr-dev libmpc-dev
fi

mkdir -p "$WORK"
cd "$WORK"
if [ ! -d toolchaincdi ]; then
    echo "== fetching toolchaincdi"
    git clone "$REPO" toolchaincdi
fi
cd toolchaincdi
git submodule update --init --depth 1 src/binutils-gdb src/gcc src/elf2mod
cd "$WORK"

# GCC needs GMP, MPFR and MPC: GMP_PREFIX=dir (with include/ and lib/), or
# the system's (libgmp-dev libmpfr-dev libmpc-dev), or else their sources
# are downloaded and built along with GCC
GMPOPT=
if [ -n "$GMP_PREFIX" ]; then
    GMPOPT="--with-gmp=$GMP_PREFIX --with-mpfr=$GMP_PREFIX --with-mpc=$GMP_PREFIX"
    export LD_LIBRARY_PATH="$GMP_PREFIX/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
elif [ ! -f /usr/include/mpc.h ]; then
    for f in gmp-6.2.1.tar.xz mpfr-4.1.0.tar.xz mpc-1.2.1.tar.gz; do
        [ -f "$f" ] || wget "https://ftp.gnu.org/gnu/${f%%-*}/$f"
    done
    G=toolchaincdi/src/gcc
    [ -d $G/gmp ]  || { tar xf gmp-6.2.1.tar.xz  && mv gmp-6.2.1  $G/gmp; }
    [ -d $G/mpfr ] || { tar xf mpfr-4.1.0.tar.xz && mv mpfr-4.1.0 $G/mpfr; }
    [ -d $G/mpc ]  || { tar xf mpc-1.2.1.tar.gz  && mv mpc-1.2.1  $G/mpc; }
fi

echo "== binutils"
mkdir -p binutils-build && cd binutils-build
../toolchaincdi/src/binutils-gdb/configure --target=m68k-elfos9 --prefix="$PREFIX" \
    --disable-multilib --with-cpu=68000 --disable-nls --disable-gdb --disable-gdbserver \
    --disable-sim --disable-gprof --disable-libctf --disable-werror MAKEINFO=true
make -j"$JOBS" MAKEINFO=true
make install MAKEINFO=true
cd ..
export PATH="$PREFIX/bin:$PATH"

echo "== gcc (C only, with libgcc)"
mkdir -p gcc-build && cd gcc-build
CFLAGS_FOR_TARGET="-O2 -mpcrel -ma6rel" ../toolchaincdi/src/gcc/configure --prefix="$PREFIX" \
    --target=m68k-elfos9 --enable-languages=c --disable-multilib --with-cpu=68000 \
    --without-headers --disable-shared --disable-nls --disable-libssp --disable-libquadmath \
    --disable-libgomp --disable-libatomic $GMPOPT MAKEINFO=true
make -j"$JOBS" all-gcc all-target-libgcc MAKEINFO=true
make install-gcc install-target-libgcc MAKEINFO=true
cd ..

echo "== elf2mod (with binutils' BFD library, from its build)"
B="$WORK/binutils-build"
cd toolchaincdi/src/elf2mod
gcc -O2 -I"$B/bfd" -I"$WORK/toolchaincdi/src/binutils-gdb/include" -o elf2mod elf2mod.c \
    "$B/bfd/.libs/libbfd.a" "$B/libiberty/libiberty.a" $( [ -f "$B/libsframe/.libs/libsframe.a" ] && echo "$B/libsframe/.libs/libsframe.a" ) \
    $( [ -f "$B/zlib/libz.a" ] && echo "$B/zlib/libz.a" || echo -lz ) -ldl
cp elf2mod "$PREFIX/bin/"
cd "$WORK"

echo
echo "Done: the CD-i toolchain is in $PREFIX/bin"
"$PREFIX/bin/m68k-elfos9-gcc" --version | head -1
echo "Add it to your PATH, e.g. in ~/.bashrc:"
echo "    export PATH=\"$PREFIX/bin:\$PATH\""
