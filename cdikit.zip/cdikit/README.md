# CD-i toolkit

Everything needed to make games and programs for the Philips CD-i, whether new homebrew or ports of existing games, in C, with ordinary PNG, WAV and video files as assets. It came out of porting MegaRace to the CD-i: the hard-won parts of that port (the display, the Digital Video Cartridge's MPEG playback, streaming from the disc, sound effects, the joypad, building bootable discs) are here as a reusable library and tools.

![Rock Run, the example game, running over an MPEG video in MAME](docs/rockrun.png)

## What's here

| | |
|---|---|
| `lib/` | **libcdi**, the C library: double-buffered 256-colour display, sprites and pictures, text, the controller, sound effects, and streaming MPEG video, MPEG music and ADPCM music from the disc |
| `tools/` | **Asset tools**: pictures (`mkgfx.py`), sound effects (`mksfx.py`), video and music streams (`mkstream.py`), bootable disc images (`mkcdi.py`), disc patches (`mkpatch.py`) |
| `examples/hello` | The smallest program: text and a box you move |
| `examples/rockrun` | **Rock Run**, a small complete game that uses everything: sprites, sound, title music, and an MPEG video background on players with the cartridge |
| `testing/` | Running programs in MAME unattended (screenshots, scripted controller input), and a speed benchmark |
| `extras/cryo/` | Decoders for Cryo Interactive's formats (MegaRace and other games of the period), for porting |
| `setup/` | Builds the compiler (Linux or Windows WSL), or a Docker image with everything |
| `docs/` | **[GUIDE.md](docs/GUIDE.md)** (start here), [HARDWARE.md](docs/HARDWARE.md) (how the CD-i parts work) |

## Quick start

```sh
sh setup/build-toolchain.sh                  # once: the compiler, into ~/cdi-toolchain
export PATH="$HOME/cdi-toolchain/bin:$PATH"
pip install numpy pillow                     # and ffmpeg, from your package manager
make                                         # the library and both examples
mame cdimono1 -cdrom examples/rockrun/rockrun.cue
```

Then read [docs/GUIDE.md](docs/GUIDE.md): setting up on Windows, writing a program, the library, the tools, testing, and porting a game.

## Status

Tested in MAME (cdimono1, with and without the Digital Video Cartridge). Not yet tested on a real CD-i player. One open issue: an intermittent freeze in MAME during long MPEG-background play (see the end of the guide). MegaRace's port, built the same way, works in MAME, but real hardware may hold surprises. Reports welcome.

MIT licence (see LICENSE). The compiler is [toolchaincdi](https://github.com/cdifan/toolchaincdi) (murachue's, with cdifan's additions), built from its sources by `setup/`.
