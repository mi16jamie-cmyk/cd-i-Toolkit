/* cdi.h - the CD-i toolkit library
 *
 * A small library for CD-i programs built with GCC (toolchaincdi):
 *   display   plane A, 384 x 280, 256 colours, double-buffered; colour 0 is
 *             see-through (the MPEG video, or black, shows through it)
 *   drawing   rectangles, images and sprites (from mkgfx.py banks), text
 *   input     the CD-i controller as a joypad (directions + buttons)
 *   files     whole files from the disc into memory
 *   sound     sound effects (ADPCM soundmaps from mksfx.py)
 *   streaming real-time files from the disc: MPEG video and MPEG music on
 *             the Digital Video Cartridge, or ADPCM music on any player
 *
 * Call order: gfx_init() first; then each frame: pad_read(), gfx_restore(),
 * draw, stream_feed() if a stream plays, gfx_swap().
 * See docs/GUIDE.md.
 */
#ifndef CDI_H
#define CDI_H

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;
typedef signed char    s8;
typedef signed short   s16;
typedef signed int     s32;

/* ------------------------------------------------------------------ system */
void cdi_exit(int status);
u32  cdi_ticks(void);               /* the system clock, in ticks */
u32  cdi_tick_rate(void);           /* ticks a second (100 on most players) */
void cdi_sleep(u32 ticks);          /* 1 = just give up the time slice */
int  cdi_has_mpeg(void);            /* 1 if a Digital Video Cartridge is in */
void cdi_catch_crashes(void);       /* debugging: a crash shows its address on
                                       the screen (uses colours 250..252) */

/* memory and files (whole files; sizes as you asked for them) */
void *mem_alloc(u32 size);          /* 0 if there isn't enough */
void  mem_free(void *p, u32 size);
void *file_load(const char *name, u32 *size);    /* 0 if it can't be read */
void  file_free(void *p, u32 size);

/* ------------------------------------------------------------------ display */
#define GFX_W 384
#define GFX_H 280
/* an image: w x h colour numbers; mkgfx.py crops away the see-through
 * border, and full_w x full_h, x, y say where the crop sits in the full
 * picture, so it draws where the whole one would (runs: see mkgfx.py) */
struct gfx_image { u16 w, h, full_w, full_h; s16 x, y; u32 runs; u8 px[]; };
int  gfx_init(void);                /* 0 on success */
u8  *gfx_back(void);                /* the buffer to draw into (GFX_W wide) */
void gfx_swap(void);                /* show it (at the next field), then wait */
/* Drawing remembers where it drew in each buffer; gfx_restore() (at the
 * start of a frame) puts the background back there, so only what moves
 * costs time. The background: a colour, and a picture over it (or 0). */
void gfx_background(const struct gfx_image *im, u8 colour);
void gfx_restore(void);
void gfx_palette(const u32 *rgb, int first, int n);   /* 0x00RRGGBB colours */
void gfx_clear(u8 colour);          /* the whole back buffer */
void gfx_clear_both(u8 colour);     /* both buffers (e.g. before a video) */
void gfx_rect(int x, int y, int w, int h, u8 colour);
void gfx_window(int x, int y, int w, int h);   /* drawing is cut to this box
                                   (labels aren't); gfx_window(0, 0, GFX_W, GFX_H) = all */
void gfx_pixel(int x, int y, u8 colour);

/* images: from a bank made by mkgfx.py (its palette + its pictures) */
struct gfx_bank;
struct gfx_bank *gfx_load_bank(const char *name);
void gfx_free_bank(struct gfx_bank *b);
const u32 *gfx_bank_palette(const struct gfx_bank *b);   /* 256 colours */
int gfx_bank_count(const struct gfx_bank *b);
const struct gfx_image *gfx_bank_image(const struct gfx_bank *b, int i);
void gfx_use_palette(const struct gfx_bank *b);          /* load all 256 */
void gfx_draw(const struct gfx_image *im, int x, int y);  /* colour 0 skipped */
void gfx_draw_opaque(const struct gfx_image *im, int x, int y);

/* text: the built-in 5x7 font, ASCII 32..126; scale 1 = 6 x 8 a character */
void gfx_text(int x, int y, const char *s, u8 colour, int scale);
int  gfx_text_width(const char *s, int scale);
char *fmt_num(char *buf, s32 n, int digits);   /* digits 0 = as many as needed */
/* labels (slots 0..15): text that stays on the screen, like a score; it is
 * only drawn when it changes, so it costs nothing on most frames */
void gfx_label(int slot, int x, int y, const char *s, u8 colour, int scale);
void gfx_label_clear(int slot);

/* ------------------------------------------------------------------ input */
#define PAD_UP     0x01
#define PAD_DOWN   0x02
#define PAD_LEFT   0x04
#define PAD_RIGHT  0x08
#define PAD_B1     0x10
#define PAD_B2     0x20
#define PAD_B12    0x40             /* buttons 1 and 2 together (or 3) */
int pad_init(void);                 /* 0 on success */
u16 pad_read(void);                 /* once a frame: PAD_ bits held */
u16 pad_pressed(void);              /* since the last pad_read: newly pressed */

/* ------------------------------------------------------------------ sound */
int  sfx_load(const char *name);    /* a mksfx.py bank: sounds loaded, or -1 */
void sfx_play(int n);               /* sound n (from 0); stops the one playing */
void sfx_stop(void);

/* ------------------------------------------------------------------ streams
 * A real-time file plays straight off the disc while the program runs.
 *   STREAM_MPEG   MPEG video and/or MPEG audio (mkstream.py --mpeg): needs
 *                 the Digital Video Cartridge; the picture shows wherever
 *                 the display is colour 0; call stream_feed() every frame
 *   STREAM_ADPCM  ADPCM audio sectors (mkstream.py --adpcm): any player;
 *                 the sound chip plays it by itself (but sound effects use
 *                 the same chip: one or the other at a time)
 * A file may hold both (an MPEG picture with ADPCM sound): pass both flags.
 */
#define STREAM_MPEG  1
#define STREAM_ADPCM 2
int  stream_play(const char *name, int flags);    /* 0 on success */
void stream_feed(void);             /* (gfx_swap also feeds while it waits) */
void stream_stop(void);
int  stream_ended(void);            /* 1 once the whole file has played */
void stream_window(int x, int y, int w, int h);   /* where the MPEG picture goes */
u32  stream_timecode(void);         /* the MPEG picture's time code */
u32  stream_sectors(void);          /* MPEG sectors fed so far */

#endif
