/* sound.c - sound effects as soundmaps on the audio processor (/ap)
 *
 * A soundmap is ADPCM sound in memory that the CD-i's audio processor plays
 * by itself. Each sound of the bank becomes one soundmap (SS_SM, SM_Creat),
 * filled once; sfx_play() starts one (SM_Out). The audio processor plays one
 * thing at a time: a new sound stops the last, and an ADPCM stream from the
 * disc stops (or is stopped by) the sounds.
 *
 * mksfx.py's bank (big-endian): u16 count, then per sound u16 sectors,
 * u16 length in 1/100 s, u32 offset of its data from the file's start; the
 * data are ADPCM sound groups, level C mono (18.9 kHz), 2304 bytes a sector.
 */
#include "cdi_internal.h"

#define SS_SM     0x3B
#define SM_CREAT  0
#define SM_OUT    1
#define SM_OFF    2
#define MAXSFX    64

static int ap = -1;
static int nsfx;
static s16 ids[MAXSFX];
static s16 playing = -1;
static u32 status[4];

static int ap_open(void)
{
    if (ap < 0) ap = os9_open("/ap", 3);
    return ap;
}

int sfx_load(const char *name)
{
    if (ap_open() < 0) return -1;
    int f = os9_open(name, 1);
    if (f < 0) return -1;
    u16 cnt;
    if (os9_read(f, &cnt, 2) != 2) { os9_close(f); return -1; }
    if (cnt > MAXSFX) cnt = MAXSFX;
    u32 tsize = 8u * cnt;
    u8 *tab = mem_alloc(tsize);
    if (!tab || os9_read(f, tab, tsize) != (s32)tsize) { os9_close(f); mem_free(tab, tsize); return -1; }
    nsfx = 0;
    for (int i = 0; i < cnt; i++) {
        u16 sec = *(u16 *)(tab + 8 * i);
        u32 off = *(u32 *)(tab + 8 * i + 4);
        struct os9_regs r = { (u32)ap, SS_SM, SM_CREAT, 4, sec * 18u, 0 };
        if (os9_setstt(&r) < 0) { ids[i] = -1; continue; }
        ids[i] = (s16)r.d0;
        if (os9_seek(f, off) < 0 || os9_read(f, (void *)r.a0, sec * 2304u) < 0) ids[i] = -1;
        nsfx = i + 1;
    }
    os9_close(f);
    mem_free(tab, tsize);
    return nsfx;
}

void sfx_play(int n)
{
    if (n < 0 || n >= nsfx || ids[n] < 0 || ap < 0) return;
    status[0] = 0;
    struct os9_regs r = { (u32)ap, SS_SM, SM_OUT, (u32)ids[n], 0, (u32)status };
    os9_setstt(&r);
    playing = ids[n];
}

void sfx_stop(void)
{
    if (ap < 0 || playing < 0) return;
    struct os9_regs r = { (u32)ap, SS_SM, SM_OFF, (u32)playing, 0, 0 };
    os9_setstt(&r);
    playing = -1;
}
