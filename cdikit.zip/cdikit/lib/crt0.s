| crt0.s - CD-i toolkit start-up and supervisor core
|
| OS-9 starts the program at `start` with a6 pointing 0x8000 into its data
| area (where -ma6rel code keeps its variables) and the stack set up. This
| clears the uninitialised data, installs the line-A handler that runs the
| few things needing supervisor mode, calls main(), and exits with its
| result.
|
| Line-A calls (a word 0xA00n in the code; supervisor mode, registers kept):
|   0xA000  feed the MPEG cartridge from the sector ring (stream.c)
|   0xA001  reset the MPEG decoders for a new stream
|   0xA002  probe for the MPEG cartridge: d0 = 1 if it answers
| The data they use is struct cdi_stream (cdi_st, a6-relative); its layout
| is fixed here and in cdi_internal.h.

        .equ    F_Exit,    0x06

        | ---- the MPEG cartridge (DVC): video decoder
        .equ    FMV_TCL,   0xE04058
        .equ    FMV_STS,   0xE0405E
        .equ    FMV_IER,   0xE04060
        .equ    FMV_SCRPOS, 0xE04074
        .equ    FMV_DECWIN, 0xE04078
        .equ    FMV_DECOFF, 0xE0407C
        .equ    FMV_PICS,  0xE040A4
        .equ    FMV_SYSCMD, 0xE040C0
        .equ    FMV_VIDCMD, 0xE040C2
        | ---- and its audio decoder
        .equ    FMA_CMD,   0xE03000
        .equ    FMA_STRM,  0xE03008
        .equ    FMA_IER,   0xE0301C
        | ---- 68070 DMA channel 1
        .equ    DMA1_CSR,  0x80004040
        .equ    DMA1_DCR,  0x80004044
        .equ    DMA1_OCR,  0x80004045
        .equ    DMA1_SCR,  0x80004046
        .equ    DMA1_CCR,  0x80004047
        .equ    DMA1_MTC,  0x8000404A
        .equ    DMA1_MAC,  0x8000404C

        | ---- play control list cells (CD-RTOS PCL)
        .equ    PCLSZ,     28
        .equ    PCL_Ctrl,  0
        .equ    PCL_Buf,   10
        .equ    PCL_Cnt,   24

        | ---- struct cdi_stream (cdi_internal.h)
        .equ    ST_IDX,    0            | w  next cell to look at
        .equ    ST_PLAY,   2            | w  decoder told to play
        .equ    ST_INIT,   4            | w  feeding enabled
        .equ    ST_NPCL,   6            | w  cells in the ring (a power of 2)
        .equ    ST_FED,    8            | l  sectors given to the cartridge
        .equ    ST_WAITS,  12           | l  DMA time-outs
        .equ    ST_PCL,    16           | l  the ring
        .equ    ST_DECWIN, 20           | l  decoder window: lines << 16 | width
        .equ    ST_SCRPOS, 24           | l  picture position on the screen
        .equ    ST_MPEG,   32           | w  this stream goes to the cartridge

        .text
        .globl  start
start:
        | clear .bss (the data area from the end of .data to `end`)
        lea     __bss_start(%a6),%a0
        lea     end(%a6),%a1
1:      cmpa.l  %a1,%a0
        bcc.s   2f
        clr.b   (%a0)+
        bra.s   1b
2:      lea     linea(%pc),%a0          | line-A vector (no MMU on the CD-i:
        move.l  %a0,0x28.w              | the vector table is plain memory)
        lea     our_a6(%pc),%a0
        move.l  %a6,(%a0)
        bsr.w   main
        move.l  %d0,%d1
        trap    #0
        .word   F_Exit
3:      bra.s   3b

| ---------------------------------------------------------------------------
| the crash screen (cdi_catch_crashes): bus error, address error, illegal
| instruction, zero divide, CHK, TRAPV and privilege violation in this
| program show what happened (crash.c) instead of the program just
| vanishing; the same faults elsewhere (a6 isn't ours) go on to OS-9
        .globl  cdi_catch_crashes
cdi_catch_crashes:
        movem.l %a0-%a1,-(%sp)
        lea     old_vec(%pc),%a1
        lea     crash_stubs(%pc),%a0
        move.l  0x08.w,(%a1)+           | bus error
        move.l  %a0,0x08.w
        addq.l  #4,%a0
        move.l  0x0C.w,(%a1)+           | address error
        move.l  %a0,0x0C.w
        addq.l  #4,%a0
        move.l  0x10.w,(%a1)+           | illegal instruction
        move.l  %a0,0x10.w
        addq.l  #4,%a0
        move.l  0x14.w,(%a1)+           | zero divide
        move.l  %a0,0x14.w
        addq.l  #4,%a0
        move.l  0x18.w,(%a1)+           | CHK
        move.l  %a0,0x18.w
        addq.l  #4,%a0
        move.l  0x1C.w,(%a1)+           | TRAPV
        move.l  %a0,0x1C.w
        addq.l  #4,%a0
        move.l  0x20.w,(%a1)+           | privilege violation
        move.l  %a0,0x20.w
        movem.l (%sp)+,%a0-%a1
        rts
crash_stubs:                            | 4 bytes each: d0 = which
        bra.s   c_bus
        nop
        bra.s   c_addr
        nop
        bra.s   c_ill
        nop
        bra.s   c_div
        nop
        bra.s   c_chk
        nop
        bra.s   c_trapv
        nop
        bra.s   c_priv
        nop
c_bus:  move.l  #0,-(%sp)
        bra.s   crash
c_addr: move.l  #1,-(%sp)
        bra.s   crash
c_ill:  move.l  #2,-(%sp)
        bra.s   crash
c_div:  move.l  #3,-(%sp)
        bra.s   crash
c_chk:  move.l  #4,-(%sp)
        bra.s   crash
c_trapv: move.l #5,-(%sp)
        bra.s   crash
c_priv: move.l  #6,-(%sp)
crash:  cmpa.l  our_a6(%pc),%a6         | ours: a6 is ours, or the PC is in
        beq.s   1f                      | this program's code (blit.s uses a6)
        move.l  %a0,-(%sp)
        lea     start(%pc),%a0              | (8+2(sp): the stacked PC)
        cmpa.l  8+2(%sp),%a0
        bhi.s   5f
        lea     __etext(%pc),%a0
        cmpa.l  8+2(%sp),%a0
        bls.s   5f
        movea.l (%sp)+,%a0
        movea.l our_a6(%pc),%a6
        bra.s   1f
5:      movea.l (%sp)+,%a0
        move.l  %a0,-(%sp)              | no: on to OS-9's handler
        move.l  4(%sp),%a0
        add.l   %a0,%a0
        add.l   %a0,%a0
        move.l  %a1,-(%sp)
        lea     old_vec(%pc),%a1
        move.l  (%a1,%a0.l),%a0
        movea.l (%sp)+,%a1
        move.l  %a0,4(%sp)
        movea.l (%sp)+,%a0
        rts                             | (to the old vector, frame intact)
1:      move.l  (%sp)+,%d0              | the type
        movea.l %sp,%a0                 | the exception frame: SR, PC ...
        move.w  #0x2700,%sr
        movea.l our_ssp(%pc),%a1
        cmpa.w  #0,%a1
        bne.s   2f
        lea     -1024(%sp),%a1          | (a stack of its own below the frame)
2:      movea.l %a1,%sp
        moveq   #0,%d1
        move.w  (%a0),%d1               | SR
        move.l  2(%a0),-(%sp)           | PC
        move.l  %d1,-(%sp)
        move.l  %d0,-(%sp)
        andi.w  #0xF8FF,%sr             | interrupts back on (the display runs)
        bsr.w   cdi_crash_screen        | (never returns)
4:      bra.s   4b
our_a6:  .long  0
our_ssp: .long  0
old_vec: .space 7*4

        .globl  cdi_exit
cdi_exit:
        move.l  4(%sp),%d1
        trap    #0
        .word   F_Exit
        bra.w   cdi_exit

| ---------------------------------------------------------------------------
| the line-A handler
linea:
        movem.l %d1-%d7/%a0-%a6,-(%sp)
        movea.l 56+2(%sp),%a0           | the stacked PC: the 0xA00n word
        move.w  (%a0),%d1
        lea     cdi_st(%a6),%a5
        cmpi.w  #0xA001,%d1
        beq.s   1f
        cmpi.w  #0xA002,%d1
        beq.s   2f
        bsr.w   feed
        bra.s   9f
1:      bsr.w   fmv_init
        bra.s   9f
2:      bsr.w   probe
9:      movem.l (%sp)+,%d1-%d7/%a0-%a6
        addq.l  #2,2(%sp)               | past the 0xA00n word
        rte

| probe: is the MPEG cartridge there? Read its status register with the bus
| error vector pointed here for a moment: no cartridge, no answer, a bus
| error. d0 = 1 if it answered.
probe:
        move.l  0x08.w,%d2
        lea     8f(%pc),%a0
        move.l  %a0,0x08.w
        movea.l %sp,%a1
        moveq   #0,%d0
        tst.w   FMV_STS
        nop
        moveq   #1,%d0
7:      move.l  %d2,0x08.w
        rts
8:      movea.l %a1,%sp                 | (the bus error frame dropped)
        moveq   #0,%d0
        bra.s   7b

| fmv_init: both decoders reset and emptied, the video decoder's window set
fmv_init:
        move.w  #0x2000,FMV_SYSCMD
        nop
        move.w  #0x0100,FMV_SYSCMD
        nop
        move.w  #0x1000,FMV_SYSCMD
        clr.w   FMV_IER
        move.w  #0x0001,FMA_CMD         | audio decoder stopped and emptied
        clr.w   FMA_STRM                | audio stream 0 (packets 0xC0)
        clr.w   FMA_IER
        clr.l   FMV_DECOFF
        move.l  ST_DECWIN(%a5),FMV_DECWIN
        move.l  ST_SCRPOS(%a5),FMV_SCRPOS
        move.w  #0x0008,FMV_VIDCMD
        clr.w   ST_PLAY(%a5)
        move.w  #1,ST_INIT(%a5)
        rts

| feed: every sector that has arrived in the ring goes to the cartridge by
| DMA, an MPEG audio packet to the audio decoder and the rest to the video
| decoder; the video decoder is told to play once it has 5 pictures
feed:
        tst.w   ST_INIT(%a5)
        beq.w   9f
        move.w  ST_NPCL(%a5),%d7
        subq.w  #1,%d7
1:      btst    #5,FMV_STS              | (the decoder can take a sector)
        beq.w   8f
        move.w  ST_IDX(%a5),%d0
        mulu.w  #PCLSZ,%d0
        movea.l ST_PCL(%a5),%a0
        adda.l  %d0,%a0
        btst    #0,PCL_Ctrl(%a0)        | (the driver filled this cell)
        beq.w   8f
        movea.l PCL_Buf(%a0),%a1
        | the stream id after the pack header, and after the system header
        | if there is one: 0xC0..0xDF is audio
        moveq   #0,%d0
        move.b  15(%a1),%d0
        cmpi.b  #0xBB,%d0
        bne.s   4f
        move.w  16(%a1),%d1
        lea     18(%a1),%a2
        move.b  3(%a2,%d1.w),%d0
4:      andi.b  #0xE0,%d0
        move.b  #0xFF,DMA1_CSR
        move.l  %a1,DMA1_MAC
        move.w  #2324/2,DMA1_MTC
        move.b  #0x04,DMA1_SCR
        move.b  #0x12,DMA1_OCR
        move.b  #0x30,DMA1_DCR
        move.b  #0x80,DMA1_CCR
        cmpi.b  #0xC0,%d0
        bne.s   5f
        move.w  #0x8000,FMA_CMD
        bra.s   6f
5:      move.w  #0x8000,FMV_SYSCMD
6:      move.l  #200000,%d1
2:      btst    #7,DMA1_CSR
        bne.s   3f
        subq.l  #1,%d1
        bne.s   2b
        addq.l  #1,ST_WAITS(%a5)
3:      clr.l   PCL_Cnt(%a0)
        clr.b   PCL_Ctrl(%a0)           | (the cell back to the driver)
        addq.l  #1,ST_FED(%a5)
        move.w  ST_IDX(%a5),%d0
        addq.w  #1,%d0
        move.w  ST_NPCL(%a5),%d1
        subq.w  #1,%d1
        and.w   %d1,%d0
        move.w  %d0,ST_IDX(%a5)
        dbra    %d7,1b
8:      tst.w   ST_PLAY(%a5)
        bne.s   9f
        cmpi.w  #5,FMV_PICS
        bcs.s   9f
        move.w  #0x0008,FMV_SYSCMD
        move.w  #0x0420,FMV_VIDCMD
        move.w  #1,ST_PLAY(%a5)
9:      rts

| ---------------------------------------------------------------------------
| C-callable doorways to the line-A calls
        .globl  cdi_feed, cdi_mpeg_reset, cdi_probe
cdi_feed:
        .word   0xA000
        rts
cdi_mpeg_reset:
        .word   0xA001
        rts
cdi_probe:
        .word   0xA002
        rts

| the MPEG decoder's time code (hours:minutes:seconds:pictures, from the
| stream's group-of-pictures headers) and pictures decoded
        .globl  cdi_mpeg_timecode
cdi_mpeg_timecode:
        move.l  FMV_TCL,%d0
        rts
