/* cdi_internal.h - shared between the library's files (not for programs) */
#ifndef CDI_INTERNAL_H
#define CDI_INTERNAL_H
#include "cdi.h"

/* os9.s */
struct os9_regs { u32 d0, d1, d2, d3, d4, a0; };
extern u16 os9_errno;
void *os9_srqmem(u32 size);
void *os9_srqcmem(u32 size, u32 type);
int   os9_srtmem(void *p, u32 size);
int   os9_open(const char *name, int mode);
int   os9_close(int path);
s32   os9_read(int path, void *buf, u32 n);
int   os9_seek(int path, u32 pos);
s32   os9_size(int path);
void  os9_sleep(u32 ticks);
u32   os9_time(u16 *rate);
int   os9_icpt(void (*handler)(void));
int   os9_setstt(struct os9_regs *r);
int   os9_getstt(struct os9_regs *r);

/* crt0.s: the stream state its supervisor code uses (layout fixed there) */
struct cdi_stream {
    u16 idx, play, init, npcl;      /*  0 */
    u32 fed, waits;                 /*  8 */
    u8 *pcl;                        /* 16 */
    u32 decwin, scrpos;             /* 20 */
    u16 ended, unused, mpeg, pad;   /* 28 */
};
extern struct cdi_stream cdi_st;
void cdi_feed(void);
void cdi_mpeg_reset(void);
int  cdi_probe(void);
u32  cdi_mpeg_timecode(void);

#endif
