/* stream.c - real-time files: playing straight off the disc
 *
 * SS_PLAY starts the CD drive on a file; it delivers the sectors at the
 * disc's speed (75 a second) while the program runs:
 *   - ADPCM audio sectors (channel 0) go straight to the audio processor,
 *     which plays them (PCB_AChan);
 *   - data sectors (channel 0) go into a ring of buffers (the play control
 *     list, PCL). For an MPEG stream they are MPEG packs, which crt0.s's
 *     feed hands to the cartridge's decoders by DMA: video packets to the
 *     video decoder, audio packets (0xC0) to its audio decoder. The feed
 *     runs from stream_feed() and while gfx_swap() waits for the next
 *     field; the ring (32 sectors, 0.43 s) covers a slow frame.
 * Sector channels 1..31 are left out, so mkstream.py's padding (channel
 * 31) costs nothing.
 */
#include "cdi_internal.h"

#define SS_PLAY  0x2D
#define SS_ABORT 0x31
#define NPCL     32
#define PCLSZ    28
#define BUFSZ    2336

struct cdi_stream cdi_st;
static u8  *ring;                   /* the PCL cells, then their buffers */
static int  path = -1;
static u32  cell;                   /* the PCB's pointer to the first cell */
static u8   pcb[32];
static u32  t_start, t_len;         /* when it started; its length in ticks */
static u32  last_fed, t_fed;        /* sectors fed, and when that last changed */

static void set_l(u8 *p, u32 v) { *(u32 *)p = v; }
static void set_w(u8 *p, u16 v) { *(u16 *)p = v; }

void stream_window(int x, int y, int w, int h)
{
    cdi_st.scrpos = ((u32)y << 16) | (u16)x;
    cdi_st.decwin = ((u32)h << 16) | (u16)w;
}

static int ring_init(void)
{
    if (ring) return 0;
    ring = mem_alloc(NPCL * PCLSZ + NPCL * BUFSZ + 16);
    if (!ring) return -1;
    cdi_st.pcl = ring;
    cdi_st.npcl = NPCL;
    if (!cdi_st.decwin) stream_window(16, 0, 352, 280);
    return 0;
}

static void ring_reset(void)
{
    u32 buf = ((u32)ring + NPCL * PCLSZ + 15) & ~15u;
    for (int i = 0; i < NPCL; i++) {
        u8 *c = ring + i * PCLSZ;
        for (int k = 0; k < PCLSZ; k++) c[k] = 0;
        set_w(c + 4, 0);                            /* PCL_Sig: none (see below) */
        set_l(c + 6, (u32)(ring + ((i + 1) % NPCL) * PCLSZ));   /* PCL_Nxt */
        set_l(c + 10, buf + (u32)i * BUFSZ);        /* PCL_Buf */
        set_l(c + 14, 1);                           /* PCL_BufSz: 1 sector */
    }
    cdi_st.idx = 0;
    cdi_st.fed = 0;
    cell = (u32)ring;
}

int stream_play(const char *name, int flags)
{
    stream_stop();
    if (ring_init() < 0) return -1;
    if ((flags & STREAM_MPEG) && !cdi_has_mpeg()) flags &= ~STREAM_MPEG;
    ring_reset();
    cdi_st.ended = 0;
    cdi_st.mpeg = (flags & STREAM_MPEG) != 0;
    if (cdi_st.mpeg) cdi_mpeg_reset(); else cdi_st.init = 0;

    path = os9_open(name, 1);
    if (path < 0) { cdi_st.init = 0; return -1; }
    /* how long it plays: its sectors (a real-time file's size counts 2048
     * bytes a sector) at 75 a second */
    s32 size = os9_size(path);
    u32 rate = cdi_tick_rate();
    t_len = size > 0 ? (u32)(size / 2048) * rate / 75 : 0;
    t_start = t_fed = cdi_ticks();
    last_fed = 0;
    /* the play control block. No signals are asked for (the library uses
     * none, which keeps programs simple): the end is noticed by time, and
     * for MPEG by the sectors stopping */
    for (int k = 0; k < 32; k++) pcb[k] = 0;
    set_l(pcb + 4, 0x7FFFFFFF);                     /* PCB_Rec: all of it */
    set_l(pcb + 8, 1);                              /* PCB_Chan: channel 0 */
    set_w(pcb + 12, (flags & STREAM_ADPCM) ? 1 : 0);    /* PCB_AChan */
    set_l(pcb + 22, cdi_st.mpeg ? (u32)&cell : 0);  /* PCB_Data: the ring */
    os9_seek(path, 0);
    struct os9_regs r = { (u32)path, SS_PLAY, 0, 0, 0, (u32)pcb };
    if (os9_setstt(&r) < 0) { os9_close(path); path = -1; cdi_st.init = 0; return -1; }
    return 0;
}

void stream_feed(void)
{
    if (path >= 0 && cdi_st.mpeg) cdi_feed();
}

void stream_stop(void)
{
    if (path < 0) return;
    cdi_st.init = 0;                /* no feeding from the signal meanwhile */
    if (cdi_st.mpeg) *(volatile u16 *)0xE03000 = 1;     /* MPEG audio off */
    struct os9_regs r = { (u32)path, SS_ABORT, 0, 0, 0, 0 };
    os9_setstt(&r);                 /* (an error just means it had ended) */
    os9_close(path);
    path = -1;
    cdi_st.mpeg = 0;
}

int stream_ended(void)
{
    if (path < 0) return 1;
    u32 now = cdi_ticks(), rate = cdi_tick_rate();
    if (now < t_start) t_start = t_fed = now;       /* (the clock wrapped) */
    if (cdi_st.mpeg) {
        /* MPEG: over when it has played its length, or no sector has come
         * for a second after some had */
        if (cdi_st.fed != last_fed) { last_fed = cdi_st.fed; t_fed = now; }
        if (last_fed && now - t_fed > rate) return 1;
        return now - t_start > t_len + 3 * rate;    /* (in case) */
    }
    return now - t_start > t_len + rate * 3 / 4;    /* (the drive takes a moment to start) */
}
u32 stream_timecode(void) { return cdi_st.mpeg ? cdi_mpeg_timecode() : 0; }
u32 stream_sectors(void) { return cdi_st.fed; }
