/* draw.c - drawing into the back buffer: rectangles, images, text
 *
 * Redrawing all 384 x 280 pixels every frame is too slow for the 68070, so
 * the library keeps, for each of the two buffers, a list of the boxes drawn
 * into it. gfx_restore() puts the background back in just those boxes (the
 * ones drawn the last time this buffer was the back one), so a frame only
 * costs what changes. The background is a colour, or a picture over it
 * (gfx_background); gfx_clear() repaints all of it.
 */
#include "cdi_internal.h"
#include "font5x7.h"

#define MAXBOX 96
struct box { s16 x, y, w, h; };
static struct box boxes[2][MAXBOX];
static int nbox[2];
static u8 full[2];                  /* the whole buffer needs restoring */
static const struct gfx_image *bg_img;
static u8 bg_col;

extern int cdi_back_index(void);    /* video.c: which buffer is the back one */
void cdi_fill(void *dst, u32 bytes, u32 v);     /* blit.s */
void cdi_runs(const u8 *src, const u16 *runs, u8 *dst, int h, int srcw);
void cdi_copy(const u8 *src, int srcw, u8 *dst, int w, int h);
static void labels_hit(int b, int x, int y, int w, int h);
static int clip_screen(int *x, int *y, int *w, int *h, int *sx, int *sy);
void cdi_fill_rect(u8 *dst, int w, int h, u32 v);

static void note(int x, int y, int w, int h)
{
    int b = cdi_back_index();
    if (full[b]) return;
    if (nbox[b] == MAXBOX) { full[b] = 1; return; }
    struct box *bx = &boxes[b][nbox[b]++];
    bx->x = x; bx->y = y; bx->w = w; bx->h = h;
}

static void note_other(int b, int x, int y, int w, int h)
{
    int sx, sy;
    if (!clip_screen(&x, &y, &w, &h, &sx, &sy) || full[b]) return;
    if (nbox[b] == MAXBOX) { full[b] = 1; return; }
    struct box *bx = &boxes[b][nbox[b]++];
    bx->x = x; bx->y = y; bx->w = w; bx->h = h;
}

static int clip(int *x, int *y, int *w, int *h, int *sx, int *sy);
/* the drawing window (gfx_window): drawing is cut to it */
static s16 wx0 = 0, wy0 = 0, wx1 = GFX_W, wy1 = GFX_H;

void gfx_window(int x, int y, int w, int h)
{
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > GFX_W) w = GFX_W - x;
    if (y + h > GFX_H) h = GFX_H - y;
    if (w < 0) w = 0;
    if (h < 0) h = 0;
    wx0 = x; wy0 = y; wx1 = x + w; wy1 = y + h;
}

/* clip a w x h box at (x, y) to the window: 0 if nothing is left; *sx, *sy
 * = how much of the source was cut off at the left and top */
static int clip_to(int *x, int *y, int *w, int *h, int *sx, int *sy, int x0, int y0, int x1, int y1)
{
    *sx = *sy = 0;
    if (*x < x0) { *sx = x0 - *x; *w -= *sx; *x = x0; }
    if (*y < y0) { *sy = y0 - *y; *h -= *sy; *y = y0; }
    if (*x + *w > x1) *w = x1 - *x;
    if (*y + *h > y1) *h = y1 - *y;
    return *w > 0 && *h > 0;
}
static int clip(int *x, int *y, int *w, int *h, int *sx, int *sy)
{
    return clip_to(x, y, w, h, sx, sy, wx0, wy0, wx1, wy1);
}
static int clip_screen(int *x, int *y, int *w, int *h, int *sx, int *sy)
{
    return clip_to(x, y, w, h, sx, sy, 0, 0, GFX_W, GFX_H);
}

static void fill_box(u8 *buf, int x, int y, int w, int h, u8 c)
{
    u8 *row = buf + y * GFX_W + x;
    if (w == GFX_W) cdi_fill(row, (u32)w * h, c * 0x01010101u);
    else cdi_fill_rect(row, w, h, c * 0x01010101u);
}

/* the background into a box of the back buffer (already clipped) */
static void restore_box(u8 *buf, int x, int y, int w, int h)
{
    if (!bg_img) { fill_box(buf, x, y, w, h, bg_col); return; }
    int iw = bg_img->w, ih = bg_img->h;             /* (a background isn't cropped:
                                                       make it with no see-through) */
    int cw = x + w <= iw ? w : iw - x;              /* the part the picture covers */
    int ch = y + h <= ih ? h : ih - y;
    if (cw > 0 && ch > 0) cdi_copy(bg_img->px + y * iw + x, iw, buf + y * GFX_W + x, cw, ch);
    else cw = ch = 0;
    if (cw < w) fill_box(buf, x + (cw > 0 ? cw : 0), y, w - (cw > 0 ? cw : 0), ch > 0 ? ch : h, bg_col);
    if (ch > 0 && ch < h) fill_box(buf, x, y + ch, w, h - ch, bg_col);
}

void gfx_background(const struct gfx_image *im, u8 colour)
{
    bg_img = im; bg_col = colour;
    full[0] = full[1] = 1;
}

void gfx_restore(void)
{
    int b = cdi_back_index();
    u8 *buf = gfx_back();
    if (full[b]) {
        if (!bg_img) cdi_fill(buf, GFX_W * GFX_H, bg_col * 0x01010101u);
        else restore_box(buf, 0, 0, GFX_W, GFX_H);
        labels_hit(b, 0, 0, GFX_W, GFX_H);
    } else {
        for (int i = 0; i < nbox[b]; i++) {
            struct box *bx = &boxes[b][i];
            restore_box(buf, bx->x, bx->y, bx->w, bx->h);
            labels_hit(b, bx->x, bx->y, bx->w, bx->h);
        }
    }
    full[b] = 0; nbox[b] = 0;
}

void gfx_clear(u8 c)
{
    cdi_fill(gfx_back(), GFX_W * GFX_H, c * 0x01010101u);
    full[cdi_back_index()] = 1;
    labels_hit(cdi_back_index(), 0, 0, GFX_W, GFX_H);
}

void gfx_clear_both(u8 c)
{
    gfx_clear(c);
    gfx_swap();
    gfx_clear(c);
}

void gfx_pixel(int x, int y, u8 c)
{
    if (x >= wx0 && x < wx1 && y >= wy0 && y < wy1) {
        gfx_back()[y * GFX_W + x] = c;
        note(x, y, 1, 1);
    }
}

void gfx_rect(int x, int y, int w, int h, u8 c)
{
    int sx, sy;
    if (!clip(&x, &y, &w, &h, &sx, &sy)) return;
    fill_box(gfx_back(), x, y, w, h, c);
    note(x, y, w, h);
}

static void draw(const struct gfx_image *im, int x, int y, int opaque)
{
    int w = im->w, h = im->h, sx, sy;
    x += im->x; y += im->y;                         /* (the crop's place) */
    if (!clip(&x, &y, &w, &h, &sx, &sy)) return;
    note(x, y, w, h);
    const u8 *src = im->px + sy * im->w + sx;
    u8 *dst = gfx_back() + y * GFX_W + x;
    if (opaque) { cdi_copy(src, im->w, dst, w, h); return; }
    if (w == im->w && h == im->h && im->runs) {     /* all on the screen */
        cdi_runs(im->px, (const u16 *)((const u8 *)im + im->runs), dst, h, w);
        return;
    }
    for (; h > 0; h--, src += im->w, dst += GFX_W) {    /* (cut by the edge) */
        const u8 *s = src; u8 *d = dst;
        for (int i = w; i > 0; i--, s++, d++) { u8 v = *s; if (v) *d = v; }
    }
}
void gfx_draw(const struct gfx_image *im, int x, int y) { draw(im, x, y, 0); }
void gfx_draw_opaque(const struct gfx_image *im, int x, int y) { draw(im, x, y, 1); }

static void glyph_fast(u8 *p, const u8 *g, u8 c, int scale)
{
    for (int r = 0; r < 7; r++) {
        u8 bits = g[r];
        if (!bits) { p += GFX_W * scale; continue; }
        if (scale == 1) {
            if (bits & 0x10) p[0] = c;
            if (bits & 0x08) p[1] = c;
            if (bits & 0x04) p[2] = c;
            if (bits & 0x02) p[3] = c;
            if (bits & 0x01) p[4] = c;
            p += GFX_W;
            continue;
        }
        for (int k = 0; k < scale; k++, p += GFX_W) {
            u8 *q = p;
            for (u8 m = 0x10; m; m >>= 1, q += scale)
                if (bits & m) for (int i = 0; i < scale; i++) q[i] = c;
        }
    }
}

static void draw_text_in(int x, int y, const char *s, u8 c, int scale, int x0, int y0, int x1, int y1)
{
    u8 *buf = gfx_back();
    for (; *s; s++, x += 6 * scale) {
        int ch = (u8)*s;
        if (ch < 32 || ch > 127) ch = '?';
        const u8 *g = font5x7[ch - 32];
        if (x >= x0 && y >= y0 && x + 5 * scale <= x1 && y + 7 * scale <= y1) {
            glyph_fast(buf + y * GFX_W + x, g, c, scale);
            continue;
        }
        for (int r = 0; r < 7 * scale; r++)                 /* (cut by the edge) */
            for (int b = 0; b < 5 * scale; b++)
                if (g[r / scale] & (0x10 >> (b / scale))) {
                    int xx = x + b, yy = y + r;
                    if (xx >= x0 && xx < x1 && yy >= y0 && yy < y1) buf[yy * GFX_W + xx] = c;
                }
    }
}
static void draw_text(int x, int y, const char *s, u8 c, int scale)  /* (labels: the whole screen) */
{
    draw_text_in(x, y, s, c, scale, 0, 0, GFX_W, GFX_H);
}

void gfx_text(int x, int y, const char *s, u8 c, int scale)
{
    if (scale < 1) scale = 1;
    int w = gfx_text_width(s, scale), h = 7 * scale, sx, sy, x0 = x, y0 = y;
    if (!clip(&x0, &y0, &w, &h, &sx, &sy)) return;
    note(x0, y0, w, h);
    draw_text_in(x, y, s, c, scale, wx0, wy0, wx1, wy1);
}

/* labels: text that stays (a score, a title) and is only drawn again in a
 * buffer when it changes there, or when something has been restored over
 * it. Per buffer and slot: `shown` = it is on the screen exactly as noted;
 * `drawn` = some of it may be (so its box is cleaned before redrawing). */
#define NLABEL 16
#define LABLEN 48
struct label { s16 x, y, w, h; u8 c, scale, shown, drawn; char s[LABLEN]; };
static struct label labels[2][NLABEL];

static void labels_hit(int b, int x, int y, int w, int h)
{
    for (int i = 0; i < NLABEL; i++) {
        struct label *l = &labels[b][i];
        if (!l->drawn) continue;
        if (x == 0 && y == 0 && w == GFX_W && h == GFX_H) { l->shown = l->drawn = 0; continue; }
        if (x < l->x + l->w && l->x < x + w && y < l->y + l->h && l->y < y + h) l->shown = 0;
    }
}

static int same(const char *a, const char *b)
{
    while (*a && *a == *b) a++, b++;
    return *a == *b;
}

static void label_wipe(int b, struct label *l)  /* its box back to the background */
{
    int ox = l->x, oy = l->y, ow = l->w, oh = l->h, sx, sy;
    l->shown = l->drawn = 0;
    if (clip_screen(&ox, &oy, &ow, &oh, &sx, &sy)) {
        restore_box(gfx_back(), ox, oy, ow, oh);
        labels_hit(b, ox, oy, ow, oh);          /* labels it overlapped: again */
    }
}

void gfx_label(int slot, int x, int y, const char *s, u8 c, int scale)
{
    if ((unsigned)slot >= NLABEL) return;
    if (scale < 1) scale = 1;
    int b = cdi_back_index();
    struct label *l = &labels[b][slot];
    if (l->shown && l->x == x && l->y == y && l->c == c && l->scale == scale && same(l->s, s)) return;
    if (l->drawn) label_wipe(b, l);
    int k = 0;
    while (s[k] && k < LABLEN - 1) { l->s[k] = s[k]; k++; }
    l->s[k] = 0;
    l->x = x; l->y = y; l->c = c; l->scale = scale;
    l->w = gfx_text_width(l->s, scale); l->h = 7 * scale;
    draw_text(x, y, l->s, c, scale);
    l->shown = l->drawn = 1;
}

void gfx_label_clear(int slot)
{
    if ((unsigned)slot >= NLABEL) return;
    int bk = cdi_back_index();
    for (int b = 0; b < 2; b++) {
        struct label *l = &labels[b][slot];
        if (!l->drawn) continue;
        if (b == bk) label_wipe(b, l);
        else { note_other(b, l->x, l->y, l->w, l->h); l->shown = l->drawn = 0; }   /* at its turn */
    }
}

int gfx_text_width(const char *s, int scale)
{
    int n = 0;
    while (*s++) n++;
    return n * 6 * (scale < 1 ? 1 : scale);
}

char *fmt_num(char *buf, s32 n, int digits)
{
    char t[12]; int k = 0, neg = n < 0;
    u32 v = neg ? (u32)-n : (u32)n;
    do { t[k++] = '0' + v % 10; v /= 10; } while (v && k < 11);
    while (k < digits && k < 11) t[k++] = '0';
    char *p = buf;
    if (neg) *p++ = '-';
    while (k) *p++ = t[--k];
    *p = 0;
    return buf;
}

/* ---------------------------------------------------------------- banks
 * mkgfx.py's format (big-endian): "CDIG", u16 version 3, u16 count,
 * 256 x u32 colours (0x00RRGGBB), count x u32 offsets (from the file's
 * start) of the images: struct gfx_image, then the runs. */
struct gfx_bank { u32 size; u8 *data; };

struct gfx_bank *gfx_load_bank(const char *name)
{
    u32 size;
    u8 *d = file_load(name, &size);
    if (!d) return 0;
    if (d[0] != 'C' || d[1] != 'D' || d[2] != 'I' || d[3] != 'G' || d[5] != 3) { file_free(d, size); return 0; }
    struct gfx_bank *b = mem_alloc(sizeof *b);
    if (!b) { file_free(d, size); return 0; }
    b->size = size; b->data = d;
    return b;
}

void gfx_free_bank(struct gfx_bank *b)
{
    if (!b) return;
    file_free(b->data, b->size);
    mem_free(b, sizeof *b);
}

int gfx_bank_count(const struct gfx_bank *b) { return *(const u16 *)(b->data + 6); }
const u32 *gfx_bank_palette(const struct gfx_bank *b) { return (const u32 *)(b->data + 8); }

const struct gfx_image *gfx_bank_image(const struct gfx_bank *b, int i)
{
    if (i < 0 || i >= gfx_bank_count(b)) return 0;
    const u32 *off = (const u32 *)(b->data + 8 + 1024);
    return (const struct gfx_image *)(b->data + off[i]);
}

void gfx_use_palette(const struct gfx_bank *b) { gfx_palette(gfx_bank_palette(b), 0, 256); }
