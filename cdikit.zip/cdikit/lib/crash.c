/* crash.c - the crash screen (cdi_catch_crashes in crt0.s): what went wrong
 * and where, drawn on the picture being shown, then the program stops */
#include "cdi_internal.h"

extern int cdi_back_index(void);

void cdi_crash_screen(int type, u32 sr, u32 pc)
{
    static const char *what[] = { "bus error", "address error", "illegal instruction",
        "divide by zero", "CHK", "TRAPV", "privilege violation" };
    static const u32 pal[3] = { 0x000000, 0xC00000, 0xFFFFFF };
    gfx_palette(pal, 250, 3);
    gfx_window(0, 0, GFX_W, GFX_H);
    /* draw into the shown buffer: swap once so the drawn one shows */
    char b[16], h[12];
    for (int k = 0; k < 2; k++) {
        gfx_rect(20, 90, GFX_W - 40, 80, 251);
        gfx_text(32, 100, "THE PROGRAM CRASHED", 252, 2);
        gfx_text(32, 124, type >= 0 && type < 7 ? what[type] : "?", 252, 1);
        u32 v = pc;
        for (int i = 7; i >= 0; i--) { int d = v & 15; h[i] = d < 10 ? '0' + d : 'A' + d - 10; v >>= 4; }
        h[8] = 0;
        gfx_text(32, 140, "at PC", 252, 1);
        gfx_text(72, 140, h, 252, 1);
        gfx_text(140, 140, "SR", 252, 1);
        gfx_text(160, 140, fmt_num(b, (s32)sr, 0), 252, 1);
        gfx_text(32, 154, "(PC minus the module's address = offset in the .elf)", 252, 1);
        gfx_swap();
    }
    for (;;) ;
}
