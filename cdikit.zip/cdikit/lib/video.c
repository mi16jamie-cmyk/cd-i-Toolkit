/* video.c - the display: plane A, CLUT8, 384 x 280, double-buffered
 *
 * The video chip (MCD212) runs a display control program each field: the
 * ICA list sets the planes up (plane A in CLUT8 over the external video,
 * which is the MPEG cartridge's picture; plane B off), then goes on to the
 * "path list": the 256 colours (4 banks of 64), then RELOAD VSR = the
 * address of the picture to show, then STOP. gfx_swap() changes that
 * address; gfx_palette() changes the colours; both take effect at the next
 * field. Colour 0 is the transparency key, so plane A is see-through there.
 */
#include "cdi_internal.h"

#define PICSZ    (GFX_W * GFX_H)
#define PLSIZE   1280
#define DCR1     (*(volatile u16 *)0x4FFFF2)
#define KEY      0x00FC00FC         /* colour 0: the see-through key */

static u32 *ica;                    /* the ICA list (bank 0) */
static u32 *pl;                     /* the path list: colours, VSR, STOP */
static u32 *vsr;                    /* the RELOAD VSR instruction in it */
static u8  *pix[2];                 /* the two pictures */
static int  back;                   /* which one is drawn into */

u8 *gfx_back(void) { return pix[back]; }
int cdi_back_index(void) { return back; }

static u32 vaddr(void *p) { return (u32)p & 0x3FFFFF; }

static u32 clut_word(int i, u32 rgb)
{
    return 0x80000000u | ((u32)(i & 63) << 24) | (rgb & 0x00FCFCFCu);
}

void gfx_palette(const u32 *rgb, int first, int n)
{
    for (int k = 0; k < n; k++) {
        int i = first + k;
        if (i < 0 || i > 255) continue;
        u32 c = rgb[k] & 0x00FCFCFCu;
        if (i == 0) c = KEY;
        else if (c == KEY) c = 0x00F800FC;          /* (would be see-through) */
        pl[(i >> 6) * 65 + 1 + (i & 63)] = clut_word(i, c);
    }
}

int gfx_init(void)
{
    ica = os9_srqcmem(256, 0x80);
    u8 *big = os9_srqcmem(PLSIZE + 2 * PICSZ, 0x80);
    if (!ica || !big) return -1;
    pl = (u32 *)big;
    pix[0] = big + PLSIZE;
    pix[1] = big + PLSIZE + PICSZ;

    /* the path list: 4 banks of (bank select, 64 colours) */
    u32 *p = pl;
    for (int b = 0; b < 4; b++) {
        *p++ = 0xC3000000u | b;
        for (int i = 0; i < 64; i++) *p++ = clut_word(i, 0);
    }
    *p++ = 0xC3000000u;             /* bank 0 again */
    *p++ = 0xDB00003Fu;             /* plane A weight: full */
    *p++ = 0xDC00003Fu;             /* plane B weight: full */
    *p++ = 0x78000010u;             /* (display parameters) */
    vsr = p;
    *p++ = 0x50000000u | vaddr(pix[0]);
    *p++ = 0;                       /* STOP */

    /* the ICA list */
    p = ica;
    *p++ = 0xC0040001u;             /* image coding: external video, A CLUT8 */
    *p++ = 0xC1000001u;             /* transparency: A on the key colour */
    *p++ = 0xC2000000u;
    *p++ = 0xC4000000u | KEY;       /* the key colour */
    *p++ = 0xC6000000u;
    *p++ = 0xC7000000u;
    *p++ = 0xC9000000u;
    *p++ = 0xD8000000u;
    *p++ = 0xD0000000u;
    *p++ = 0xDB00003Fu;
    *p++ = 0x40000000u | ((u32)pl & 0x7FFFF);   /* go on in the path list */

    for (int i = 0; i < PICSZ / 4; i++) {
        ((u32 *)pix[0])[i] = 0;
        ((u32 *)pix[1])[i] = 0;
    }
    static const u32 grey[2] = { 0, 0x00FCFCFC };
    gfx_palette(grey, 0, 2);
    back = 1;

    /* the video chip's channel 1 starts its ICA list here, every field */
    volatile u32 *start = (volatile u32 *)0x400;
    start[0] = start[1] = 0x40000000u | ((u32)ica & 0x7FFFF);
    u16 d = DCR1;
    d |= 0x8200;                    /* display on, ICA on */
    d &= ~0x0100;                   /* DCA off: one picture a field */
    DCR1 = d;
    return pad_init();
}

void gfx_swap(void)
{
    *vsr = 0x50000000u | vaddr(pix[back]);
    back ^= 1;
    /* the old picture stays on the screen until the chip reloads VSR at the
     * start of the next field. The field parity (CSR1R bit 5) changes when
     * a field's last line has been shown: then the old picture is free */
    volatile u8 *csr = (volatile u8 *)0x4FFFF1;
    u8 p = *csr & 0x20;
    u32 t0 = cdi_ticks();
    while ((*csr & 0x20) == p) {
        stream_feed();                              /* (the wait is free time) */
        if (cdi_ticks() - t0 > 10) break;           /* (never stuck) */
    }
}
