| pad.s - the CD-i controller as a joypad
|
| The CD-i controller is a pointing device (thumbpad, joystick, mouse) with
| two buttons. pad_read() turns it into a joypad: the pointer is put back in
| the middle after every read, so movement since the last read gives the
| directions; a direction is held for a few reads after the last movement,
| so a steady push doesn't flicker when the controller reports less often
| than once a frame.
|
|   PAD_UP 0x01  PAD_DOWN 0x02  PAD_LEFT 0x04  PAD_RIGHT 0x08
|   PAD_B1 0x10  PAD_B2 0x20    PAD_B12 0x40 (1 and 2 together, or button 3)
|
| int pad_init(void): opens /ptr; 0, or -1.   u16 pad_read(void): once a
| frame.   u16 pad_pressed(void): bits that went on at the last pad_read.

        .equ    I_Open,   0x84
        .equ    I_GetStt, 0x8D
        .equ    I_SetStt, 0x8E
        .equ    SS_PT,    0x59          | pointer status call
        .equ    PT_Coord, 0             | GetStat: d0 = buttons, d1 = x:y
        .equ    PT_Pos,   3             | SetStat: move pointer to d3 = x:y
        .equ    CX,       360           | centre, in pointer units
        .equ    CY,       240
        .equ    DEAD,     1             | ignore movement up to this many units
        .equ    HOLD,     4             | frames a direction stays on

        .bss
        .even
        .globl  pad_path, pad_raw
pad_last:  .space 2                     | the previous read
pad_new:   .space 2                     | newly pressed at the last read
pad_path:  .space 2                     | OS-9 path to /ptr
pad_hold:  .space 2                     | frames left on the held direction
pad_dirs:  .space 2                     | held direction bits
pad_raw:   .space 6                     | last raw read: buttons.w, x.w, y.w

        .text
        .globl  pad_init, pad_read, pad_pressed

pad_init:
        move.l  %a0,-(%sp)
        lea     ptrname(%pc),%a0
        moveq   #1,%d0                  | read access
        move.b  #0x84,os9_inside(%a6)
        trap    #0
        .word   I_Open
        sf      os9_inside(%a6)
        bcs.s   9f
        move.w  %d0,pad_path(%a6)
        clr.w   pad_hold(%a6)
        clr.w   pad_dirs(%a6)
        bsr.s   pad_centre
        moveq   #0,%d0
        movea.l (%sp)+,%a0
        rts
9:      moveq   #-1,%d0
        movea.l (%sp)+,%a0
        rts

pad_centre:
        movem.l %d0-%d3,-(%sp)
        move.w  pad_path(%a6),%d0
        move.w  #SS_PT,%d1
        moveq   #PT_Pos,%d2
        move.l  #(CX<<16)+CY,%d3
        move.b  #0x8E,os9_inside(%a6)
        trap    #0
        .word   I_SetStt
        sf      os9_inside(%a6)
        movem.l (%sp)+,%d0-%d3
        rts

pad_read:
        movem.l %d1-%d4,-(%sp)
        move.w  pad_path(%a6),%d0
        move.w  #SS_PT,%d1
        moveq   #PT_Coord,%d2
        move.b  #0x8D,os9_inside(%a6)
        trap    #0
        .word   I_GetStt
        sf      os9_inside(%a6)
        bcs.w   8f
        move.w  %d0,pad_raw(%a6)
        move.l  %d1,pad_raw+2(%a6)

        | ---- buttons
        moveq   #0,%d4
        move.w  %d0,%d2
        andi.w  #3,%d2
        cmpi.w  #3,%d2
        bne.s   1f
        bset    #6,%d4                  | 1 + 2 together
        bra.s   4f
1:      btst    #0,%d0
        beq.s   2f
        bset    #4,%d4                  | button 1
2:      btst    #1,%d0
        beq.s   4f
        bset    #5,%d4                  | button 2

        | ---- directions from movement since the last read
4:      moveq   #0,%d3
        move.w  %d1,%d2
        subi.w  #CY,%d2                 | d2 = dy
        swap    %d1
        subi.w  #CX,%d1                 | d1 = dx
        cmpi.w  #-DEAD,%d1
        bge.s   5f
        bset    #2,%d3                  | Left
5:      cmpi.w  #DEAD,%d1
        ble.s   6f
        bset    #3,%d3                  | Right
6:      cmpi.w  #-DEAD,%d2
        bge.s   7f
        bset    #0,%d3                  | Up
7:      cmpi.w  #DEAD,%d2
        ble.s   10f
        bset    #1,%d3                  | Down
10:     tst.w   %d3
        beq.s   11f
        move.w  %d3,pad_dirs(%a6)       | new movement: hold it
        move.w  #HOLD,pad_hold(%a6)
        bsr.w   pad_centre
        bra.s   12f
11:     tst.w   pad_hold(%a6)           | no movement: keep the last one a while
        beq.s   13f
        subq.w  #1,pad_hold(%a6)
12:     or.w    pad_dirs(%a6),%d4
13:
14:     moveq   #0,%d0
        move.b  %d4,%d0
        move.w  pad_last(%a6),%d1
        not.w   %d1
        and.w   %d0,%d1
        move.w  %d1,pad_new(%a6)
        move.w  %d0,pad_last(%a6)
        movem.l (%sp)+,%d1-%d4
        rts

pad_pressed:
        moveq   #0,%d0
        move.w  pad_new(%a6),%d0
        rts

8:      moveq   #0,%d0                  | read failed: nothing pressed
        clr.w   pad_new(%a6)
        clr.w   pad_last(%a6)
        movem.l (%sp)+,%d1-%d4
        rts

ptrname: .asciz "/ptr"
        .even
