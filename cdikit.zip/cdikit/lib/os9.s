| os9.s - C-callable OS-9 system calls (GCC m68k convention: arguments on
| the stack, result in d0; d0-d1/a0-a1 may be changed). Each returns -1 (or
| 0 for a pointer) on error, with the OS-9 error code in os9_errno.

        .equ    F_Icpt,    0x09
        .equ    F_Sleep,   0x0A
        .equ    F_Time,    0x15
        .equ    F_SRqMem,  0x28
        .equ    F_SRtMem,  0x29
        .equ    F_SRqCMem, 0x5C
        .equ    I_Open,    0x84
        .equ    I_Seek,    0x88
        .equ    I_Read,    0x89
        .equ    I_Write,   0x8A
        .equ    I_GetStt,  0x8D
        .equ    I_SetStt,  0x8E
        .equ    I_Close,   0x8F

        .bss
        .even
        .globl  os9_errno
os9_errno: .space 2
        .globl  os9_inside
os9_inside: .space 2                    | the call in progress (for debugging a hang)

        .text
        .globl  os9_srqmem, os9_srqcmem, os9_srtmem, os9_open, os9_close
        .globl  os9_read, os9_seek, os9_size, os9_sleep, os9_time, os9_icpt
        .globl  os9_setstt, os9_getstt

| void *os9_srqmem(u32 size): memory, size rounded up by OS-9 (keep the size
| you asked for: os9_srtmem rounds it the same way)
os9_srqmem:
        move.l  %a2,-(%sp)
        move.l  8(%sp),%d0
        move.b  #F_SRqMem,os9_inside(%a6)
        trap    #0
        .word   F_SRqMem
        sf      os9_inside(%a6)                | (sf keeps the flags)
        bcs.s   err_a2
        move.l  %a2,%d0
        movea.l (%sp)+,%a2
        rts

| void *os9_srqcmem(u32 size, u32 type): coloured memory (type 0x80 =
| video bank 1, 0x81 = bank 2: what the display chip can see)
os9_srqcmem:
        move.l  %a2,-(%sp)
        move.l  8(%sp),%d0
        move.l  12(%sp),%d1
        move.b  #F_SRqCMem,os9_inside(%a6)
        trap    #0
        .word   F_SRqCMem
        sf      os9_inside(%a6)                | (sf keeps the flags)
        bcs.s   err_a2
        move.l  %a2,%d0
        movea.l (%sp)+,%a2
        rts
err_a2: movea.l (%sp)+,%a2
        move.w  %d1,os9_errno(%a6)
        moveq   #0,%d0
        rts

| int os9_srtmem(void *p, u32 size)
os9_srtmem:
        move.l  %a2,-(%sp)
        movea.l 8(%sp),%a2
        move.l  12(%sp),%d0
        move.b  #F_SRtMem,os9_inside(%a6)
        trap    #0
        .word   F_SRtMem
        sf      os9_inside(%a6)                | (sf keeps the flags)
        movea.l (%sp)+,%a2
        bcs.w   err
        moveq   #0,%d0
        rts
err:    move.w  %d1,os9_errno(%a6)
        moveq   #-1,%d0
        rts

| int os9_open(const char *name, int mode): path, mode 1 read, 2 write
os9_open:
        movea.l 4(%sp),%a0
        move.l  8(%sp),%d0
        move.b  #I_Open,os9_inside(%a6)
        trap    #0
        .word   I_Open
        sf      os9_inside(%a6)                | (sf keeps the flags)
        bcs.w   err
        ext.l   %d0
        rts

| int os9_close(int path)
os9_close:
        move.l  4(%sp),%d0
        move.b  #I_Close,os9_inside(%a6)
        trap    #0
        .word   I_Close
        sf      os9_inside(%a6)                | (sf keeps the flags)
        bcs.w   err
        moveq   #0,%d0
        rts

| s32 os9_read(int path, void *buf, u32 n): bytes read
os9_read:
        move.l  4(%sp),%d0
        movea.l 8(%sp),%a0
        move.l  12(%sp),%d1
        move.b  #I_Read,os9_inside(%a6)
        trap    #0
        .word   I_Read
        sf      os9_inside(%a6)                | (sf keeps the flags)
        bcs.w   err
        move.l  %d1,%d0
        rts

| int os9_seek(int path, u32 pos)
os9_seek:
        move.l  4(%sp),%d0
        move.l  8(%sp),%d1
        move.b  #I_Seek,os9_inside(%a6)
        trap    #0
        .word   I_Seek
        sf      os9_inside(%a6)                | (sf keeps the flags)
        bcs.w   err
        moveq   #0,%d0
        rts

| s32 os9_size(int path): the file's size (SS_Size)
os9_size:
        move.l  %d2,-(%sp)
        move.l  8(%sp),%d0
        moveq   #2,%d1
        move.b  #I_GetStt,os9_inside(%a6)
        trap    #0
        .word   I_GetStt
        sf      os9_inside(%a6)                | (sf keeps the flags)
        bcs.s   1f
        move.l  %d2,%d0
        move.l  (%sp)+,%d2
        rts
1:      move.l  (%sp)+,%d2
        bra.w   err

| void os9_sleep(u32 ticks): 0 = until a signal, 1 = give up the time slice
os9_sleep:
        move.l  4(%sp),%d0
        move.b  #F_Sleep,os9_inside(%a6)
        trap    #0
        .word   F_Sleep
        sf      os9_inside(%a6)                | (sf keeps the flags)
        rts

| u32 os9_time(u16 *rate): ticks since start-up of the day (seconds mod
| 4096 x rate + tick); *rate = ticks a second (if not null)
os9_time:
        movem.l %d2-%d3,-(%sp)
        moveq   #3,%d0
        move.b  #F_Time,os9_inside(%a6)
        trap    #0
        .word   F_Time
        sf      os9_inside(%a6)                | (sf keeps the flags)
        andi.l  #0x0FFF,%d0
        move.l  %d3,%d1
        swap    %d1
        movea.l 12(%sp),%a0
        cmpa.w  #0,%a0
        beq.s   1f
        move.w  %d1,(%a0)
1:      mulu.w  %d1,%d0
        andi.l  #0xFFFF,%d3
        add.l   %d3,%d0
        movem.l (%sp)+,%d2-%d3
        rts

| int os9_icpt(void (*handler)(void)): signals go to handler (with this
| program's a6); it must end with F_RTE. (The library itself uses no signals.)
os9_icpt:
        movea.l 4(%sp),%a0
        movea.l %a6,%a1
        move.b  #F_Icpt,os9_inside(%a6)
        trap    #0
        .word   F_Icpt
        sf      os9_inside(%a6)                | (sf keeps the flags)
        bcs.w   err
        moveq   #0,%d0
        rts

| s32 os9_setstt(struct os9_regs *r) / os9_getstt: I_SetStt / I_GetStt with
| d0..d4 and a0 from r (r->d0 = path, r->d1 = function code); the
| registers after the call are written back to r. Returns 0, or -1.
        .equ    R_D0, 0
        .equ    R_D1, 4
        .equ    R_D2, 8
        .equ    R_D3, 12
        .equ    R_D4, 16
        .equ    R_A0, 20
os9_setstt:
        movem.l %d2-%d4/%a2,-(%sp)
        movea.l 20(%sp),%a2
        movem.l (%a2),%d0-%d4/%a0
        move.b  #I_SetStt,os9_inside(%a6)
        trap    #0
        .word   I_SetStt
        sf      os9_inside(%a6)                | (sf keeps the flags)
        bra.s   1f
os9_getstt:
        movem.l %d2-%d4/%a2,-(%sp)
        movea.l 20(%sp),%a2
        movem.l (%a2),%d0-%d4/%a0
        move.b  #I_GetStt,os9_inside(%a6)
        trap    #0
        .word   I_GetStt
        sf      os9_inside(%a6)                | (sf keeps the flags)
1:      movem.l %d0-%d4/%a0,(%a2)       | (movem doesn't touch the flags)
        movem.l (%sp)+,%d2-%d4/%a2
        bcs.s   2f
        moveq   #0,%d0
        rts
2:      move.w  %d1,os9_errno(%a6)
        moveq   #-1,%d0
        rts
