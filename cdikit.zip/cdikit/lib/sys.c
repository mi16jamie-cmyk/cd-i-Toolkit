/* sys.c - clock, memory, files, the MPEG cartridge check */
#include "cdi_internal.h"

static u16 rate = 100;

u32 cdi_ticks(void) { return os9_time(&rate); }
u32 cdi_tick_rate(void) { if (!rate) os9_time(&rate); return rate ? rate : 100; }
void cdi_sleep(u32 ticks) { os9_sleep(ticks); }

int cdi_has_mpeg(void)
{
    static s8 known = -1;
    if (known < 0) known = (s8)cdi_probe();
    return known;
}

void *mem_alloc(u32 size) { return os9_srqmem((size + 1) & ~1u); }
void mem_free(void *p, u32 size) { if (p) os9_srtmem(p, (size + 1) & ~1u); }

void *file_load(const char *name, u32 *size)
{
    int path = os9_open(name, 1);
    if (path < 0) return 0;
    s32 n = os9_size(path);
    u8 *p = 0;
    if (n > 0 && (p = mem_alloc((u32)n)) != 0) {
        if (os9_read(path, p, (u32)n) != n) { mem_free(p, (u32)n); p = 0; }
    }
    os9_close(path);
    if (p && size) *size = (u32)n;
    return p;
}

void file_free(void *p, u32 size) { mem_free(p, size); }
