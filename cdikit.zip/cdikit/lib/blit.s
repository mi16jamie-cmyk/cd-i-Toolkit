| blit.s - the drawing inner loops (the 68070 is slow; these are tight)
        .equ    SW, 384                 | the screen's width

        .text
| void cdi_fill(void *dst, u32 bytes, u32 value): dst even; 48-byte blocks
| with movem, then longs, then bytes
        .globl  cdi_fill
cdi_fill:
        movem.l %d2-%d7/%a2-%a6,-(%sp)
        movea.l 48(%sp),%a0
        move.l  52(%sp),%d0
        move.l  56(%sp),%d1
        move.l  %d1,%d2
        move.l  %d1,%d3
        move.l  %d1,%d4
        move.l  %d1,%d5
        move.l  %d1,%d6
        move.l  %d1,%d7
        movea.l %d1,%a1
        movea.l %d1,%a2
        movea.l %d1,%a3
        movea.l %d1,%a4
        movea.l %d1,%a5
        lea     (%a0,%d0.l),%a6         | the end: movem fills down from it
1:      cmpi.l  #48,%d0
        bcs.s   2f
        movem.l %d1-%d7/%a1-%a5,-(%a6)
        subi.l  #48,%d0
        bra.s   1b
2:      subq.l  #4,%d0
        bcs.s   3f
        move.l  %d1,-(%a6)
        bra.s   2b
3:      addq.l  #4,%d0
        beq.s   9f
4:      move.b  %d1,-(%a6)
        subq.l  #1,%d0
        bne.s   4b
9:      movem.l (%sp)+,%d2-%d7/%a2-%a6
        rts

| void cdi_runs(const u8 *src, const u16 *runs, u8 *dst, int h, int srcw):
| an image's solid stretches (mkgfx.py's runs: u16 skip, u16 length ...,
| 0xFFFF a row) copied to the screen; the see-through pixels cost nothing
        .globl  cdi_runs
cdi_runs:
        movem.l %d2-%d4/%a2-%a4,-(%sp)
        movea.l 28(%sp),%a0             | src row
        movea.l 32(%sp),%a1             | runs
        movea.l 36(%sp),%a2             | dst row
        move.l  40(%sp),%d3             | rows
        move.l  44(%sp),%d4             | src width
        bra.s   5f
1:      movea.l %a0,%a3
        movea.l %a2,%a4
2:      move.w  (%a1)+,%d0              | skip
        cmpi.w  #-1,%d0
        beq.s   4f
        adda.w  %d0,%a3
        adda.w  %d0,%a4
        move.w  (%a1)+,%d1              | length
        subq.w  #1,%d1
3:      move.b  (%a3)+,(%a4)+
        dbra    %d1,3b
        bra.s   2b
4:      adda.l  %d4,%a0
        lea     SW(%a2),%a2
5:      subq.l  #1,%d3
        bpl.s   1b
        movem.l (%sp)+,%d2-%d4/%a2-%a4
        rts

| void cdi_copy(const u8 *src, int srcw, u8 *dst, int w, int h): a
| rectangle; when both rows start even: 40-byte blocks with movem, then
| longs, then bytes; else bytes
        .globl  cdi_copy
cdi_copy:
        movem.l %d2-%d7/%a2-%a6,-(%sp)
        movea.l 48(%sp),%a0
        movea.l 56(%sp),%a1
        bra.w   9f
1:      movea.l %a0,%a2
        movea.l %a1,%a3
        move.l  60(%sp),%d0             | w
        move.l  %a2,%d1
        move.l  %a3,%d2
        or.l    %d2,%d1
        btst    #0,%d1
        bne.s   6f                      | (an odd start: bytes)
        bra.s   3f
2:      movem.l (%a2)+,%d1-%d7/%a4-%a6  | 40 bytes
        movem.l %d1-%d7/%a4-%a6,(%a3)
        lea     40(%a3),%a3
3:      subi.l  #40,%d0
        bcc.s   2b
        addi.l  #40,%d0
        move.w  %d0,%d1
        lsr.w   #2,%d1
        andi.w  #3,%d0
        bra.s   5f
4:      move.l  (%a2)+,(%a3)+
5:      dbra    %d1,4b
        bra.s   7f
6:      move.b  (%a2)+,(%a3)+
7:      dbra    %d0,6b
        adda.l  52(%sp),%a0             | src width
        lea     SW(%a1),%a1
9:      subq.l  #1,64(%sp)              | h
        bpl.w   1b
        movem.l (%sp)+,%d2-%d7/%a2-%a6
        rts

| void cdi_fill_rect(u8 *dst, int w, int h, u32 value): value = the colour
| in all 4 bytes; rows of the screen
        .globl  cdi_fill_rect
cdi_fill_rect:
        movem.l %d2-%d7/%a2-%a6,-(%sp)
        movea.l 48(%sp),%a0
        move.l  60(%sp),%d1
        move.l  %d1,%d2
        move.l  %d1,%d3
        move.l  %d1,%d4
        move.l  %d1,%d5
        move.l  %d1,%d6
        movea.l %d1,%a2
        movea.l %d1,%a3
        movea.l %d1,%a4
        movea.l %d1,%a5
        bra.s   9f
1:      movea.l %a0,%a1
        move.l  52(%sp),%d0             | w
        move.l  %a1,%d7
        btst    #0,%d7
        beq.s   2f
        move.b  %d1,(%a1)+              | (to an even address)
        subq.l  #1,%d0
        bra.s   2f
3:      movem.l %d1-%d6/%a2-%a5,(%a1)   | 40 bytes
        lea     40(%a1),%a1
2:      subi.l  #40,%d0
        bcc.s   3b
        addi.l  #40,%d0
        move.w  %d0,%d7
        lsr.w   #2,%d7
        andi.w  #3,%d0
        bra.s   5f
4:      move.l  %d1,(%a1)+
5:      dbra    %d7,4b
        bra.s   7f
6:      move.b  %d1,(%a1)+
7:      dbra    %d0,6b
        lea     SW(%a0),%a0
9:      subq.l  #1,56(%sp)              | h
        bpl.s   1b
        movem.l (%sp)+,%d2-%d7/%a2-%a6
        rts
