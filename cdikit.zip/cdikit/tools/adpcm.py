"""adpcm.py - CD-i (CD-ROM XA) ADPCM encoding, and reading any sound file

The CD-i's audio processor plays 4-bit ADPCM in sound groups of 128 bytes:
16 bytes of parameters (the filter and range of each of the 8 sound units,
each written twice), then 28 x 4 bytes holding the 8 units' 28 samples
(byte 4i+j: unit 2j in the low nibble, unit 2j+1 in the high one). 18
groups fill a 2304-byte sector. Mono: the units follow each other in time;
stereo: they alternate left, right.

  level B: 37.8 kHz   level C: 18.9 kHz
  coding byte (sector subheader): +1 stereo, +4 level C
  sectors needed: level C mono 1 in 16, C stereo / B mono 1 in 8, B stereo 1 in 4
"""
import subprocess, numpy as np

K0 = np.array([0, 60, 115, 98]); K1 = np.array([0, 0, -52, -55])
F = np.repeat(np.arange(4), 13)                 # 52 candidates: filter x range
SH = np.tile(12 - np.arange(13), 4)

def _unit(x, s1, s2):
    """28 samples -> (parameter byte, 28 nibbles, s1, s2): the best of the 52"""
    a = np.full(52, s1, np.int64); b = np.full(52, s2, np.int64)
    err = np.zeros(52); q = np.zeros((28, 52), np.int64)
    k0 = K0[F]; k1 = K1[F]; div = (1 << SH).astype(float)
    for i in range(28):
        v = x[i]
        pred = (a * k0 + b * k1 + 32) >> 6
        qq = np.clip(np.rint((v - pred) / div), -8, 7).astype(np.int64)
        out = np.clip((qq << SH) + pred, -32768, 32767)
        err += (v - out) ** 2
        q[i] = qq; b = a; a = out
    c = int(np.argmin(err))
    return (int(F[c]) << 4) | (12 - int(SH[c])), q[:, c] & 15, int(a[c]), int(b[c])

def encode(samples, stereo=False):
    """16-bit samples (mono: 1-D; stereo: N x 2) -> (sectors, data bytes).
    The data are whole 2304-byte sectors (silence at the end)."""
    s = np.asarray(samples, float)
    chans = [s[:, 0], s[:, 1]] if stereo else [s if s.ndim == 1 else s.mean(1)]
    per = (112 if stereo else 224) * 18         # samples a channel, a sector
    n = len(chans[0]); nsec = max(1, -(-n // per))
    chans = [np.concatenate([c, np.zeros(nsec * per - n)]).astype(np.int64) for c in chans]
    st = [[0, 0] for _ in chans]
    out = bytearray()
    for g in range(nsec * 18):
        params, nibs = [], []
        for u in range(8):
            ch = u & 1 if stereo else 0
            k = (g * 4 + u // 2) if stereo else (g * 8 + u)     # the unit's place in its channel
            x = chans[ch][k * 28:(k + 1) * 28]
            p, nb, st[ch][0], st[ch][1] = _unit(x, st[ch][0], st[ch][1])
            params.append(p); nibs.append(nb)
        grp = bytearray(128)
        for u in range(4):
            grp[u] = grp[u + 4] = params[u]; grp[8 + u] = grp[12 + u] = params[4 + u]
        for i in range(28):
            for j in range(4):
                grp[16 + 4 * i + j] = int(nibs[2 * j][i]) | (int(nibs[2 * j + 1][i]) << 4)
        out += grp
    return nsec, bytes(out)

def read_audio(path, rate, stereo=False, gain=1.0, normalise=None):
    """Any sound file ffmpeg reads -> 16-bit samples at `rate` (1-D, or N x 2).
    normalise: scale so the peak is this (e.g. 16000), else multiply by gain."""
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-f', 's16le', '-ac', '2' if stereo else '1',
                          '-ar', str(rate), '-'], check=True, capture_output=True).stdout
    s = np.frombuffer(raw, np.int16).astype(float)
    if stereo: s = s.reshape(-1, 2)
    if normalise and len(s): s = s * (normalise / max(1.0, np.abs(s).max()))
    else: s = s * gain
    return np.clip(s, -32767, 32767)
