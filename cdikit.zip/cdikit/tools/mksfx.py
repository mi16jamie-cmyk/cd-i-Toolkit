#!/usr/bin/env python3
"""mksfx.py - sound effects for a CD-i program (a bank for sfx_load)

    mksfx.py OUT.SFX [--header out.h] [--peak N] SOUND ...

Each SOUND (WAV, MP3, OGG ... anything ffmpeg reads) becomes sound n (from
0, in the order given), as CD-i ADPCM level C mono (18.9 kHz), which the
audio processor plays from memory (a soundmap). Each sound is normalised to
the same loudness (--peak, default 16000 of 32767; lower it if sounds
distort on the player). --header writes SFX_<NAME> numbers.

Memory: each sound takes 2304 bytes for every 0.21 s (about 11 KB a second).

Format (big-endian): u16 count, count x (u16 sectors, u16 length in
1/100 s, u32 offset from the file's start), then the ADPCM sectors.
"""
import sys, os, re, struct, argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from adpcm import encode, read_audio

ap = argparse.ArgumentParser(description=__doc__.split('\n')[1])
ap.add_argument('out')
ap.add_argument('sounds', nargs='+')
ap.add_argument('--header')
ap.add_argument('--peak', type=float, default=16000)
a = ap.parse_args()

hdr = bytearray(struct.pack('>H', len(a.sounds)))
body = bytearray()
base = 2 + 8 * len(a.sounds)
names = []
for path in a.sounds:
    s = read_audio(path, 18900, normalise=a.peak)
    nsec, data = encode(s)
    hdr += struct.pack('>HHI', nsec, min(65535, len(s) * 100 // 18900 + 1), base + len(body))
    body += data
    names.append(re.sub(r'\W', '_', os.path.splitext(os.path.basename(path))[0]).upper())
    print('  %-20s %5.2f s  %3d sectors' % (os.path.basename(path), len(s) / 18900, nsec))
open(a.out, 'wb').write(hdr + body)
print('%s: %d sounds, %d bytes' % (a.out, len(a.sounds), len(hdr) + len(body)))
if a.header:
    g = re.sub(r'\W', '_', os.path.basename(a.out)).upper()
    with open(a.header, 'w') as f:
        f.write('/* made by mksfx.py */\n#ifndef %s_H\n#define %s_H\n' % (g, g))
        for i, n in enumerate(names): f.write('#define SFX_%s %d\n' % (n, i))
        f.write('#define SFX_COUNT %d\n#endif\n' % len(names))
