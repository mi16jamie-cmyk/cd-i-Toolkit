#!/usr/bin/env python3
"""mkcdi.py - build a CD-i Bridge disc image (MODE2/2352 .bin + .cue).

A minimal Python take on what psxbuild (psximager, CD-i branch) does for
toolchaincdi: an ISO 9660 volume with XA extensions, written as Mode 2 Form 1
sectors, with the system identifier "CD-RTOS CD-BRIDGE" and the application
identifier naming the boot module. The CD-i player's launcher reads the
application identifier and runs that file.

Usage: mkcdi.py OUT_BASENAME VOLUME_ID APP_FILE [OTHER_FILE ...]
       (all files go in the root directory; APP_FILE is the boot module)
"""
import os, struct, sys, time

SECTOR = 2352
SYNC = b'\x00' + b'\xff' * 10 + b'\x00'

# Submode bits (CD-ROM XA)
SM_EOR, SM_VIDEO, SM_AUDIO, SM_DATA, SM_TRIG, SM_FORM2, SM_RT, SM_EOF = 1, 2, 4, 8, 16, 32, 64, 128

# ---------------------------------------------------------------- EDC / ECC
EDC_LUT = []
for i in range(256):
    e = i
    for _ in range(8):
        e = (e >> 1) ^ (0xD8018001 if e & 1 else 0)
    EDC_LUT.append(e)

def edc(data):
    e = 0
    for b in data:
        e = EDC_LUT[(e ^ b) & 0xFF] ^ (e >> 8)
    return e

ECC_F = [0] * 256
ECC_B = [0] * 256
for i in range(256):
    j = (i << 1) ^ (0x11D if i & 0x80 else 0)
    ECC_F[i] = j & 0xFF
    ECC_B[i ^ j & 0xFF] = i

def _ecc_block(src, major_count, minor_count, major_mult, minor_inc):
    """src: 0x930-0x0C bytes starting at header (offset 12). Returns parity."""
    size = major_count * minor_count
    out = bytearray(major_count * 2)
    for major in range(major_count):
        index = (major >> 1) * major_mult + (major & 1)
        ecc_a = 0
        ecc_b = 0
        for minor in range(minor_count):
            temp = src[index]
            index += minor_inc
            if index >= size:
                index -= size
            ecc_a ^= temp
            ecc_b ^= temp
            ecc_a = ECC_F[ecc_a]
        ecc_a = ECC_B[ECC_F[ecc_a] ^ ecc_b]
        out[major] = ecc_a
        out[major + major_count] = ecc_a ^ ecc_b
    return out

def ecc_generate(sector):
    """Fill P and Q parity of a Mode 2 Form 1 sector (header zeroed for calc)."""
    saved = sector[12:16]
    sector[12:16] = b'\0\0\0\0'
    p = _ecc_block(sector[12:12 + 2064], 86, 24, 2, 86)
    sector[0x81C:0x81C + 172] = p
    q = _ecc_block(sector[12:12 + 2236], 52, 43, 86, 88)
    sector[0x8C8:0x8C8 + 104] = q
    sector[12:16] = saved

def bcd(n):
    return ((n // 10) << 4) | (n % 10)

def msf(lba):
    lba += 150
    return bytes([bcd(lba // 4500), bcd((lba // 75) % 60), bcd(lba % 75)])

def make_sector(lba, data, submode=SM_DATA, form2=False, file_no=0, channel=0, coding=0, no_edc=False):
    s = bytearray(SECTOR)
    s[0:12] = SYNC
    s[12:15] = msf(lba)
    s[15] = 2
    sub = bytes([file_no, channel, submode | (SM_FORM2 if form2 else 0), coding])
    s[16:20] = sub
    s[20:24] = sub
    if form2:
        s[24:24 + len(data)] = data
        if not no_edc:              # Form 2 EDC is optional (0 = not used)
            s[2348:2352] = struct.pack('<I', edc(s[16:2348]))
    else:
        assert len(data) <= 2048
        s[24:24 + len(data)] = data
        s[2072:2076] = struct.pack('<I', edc(s[16:2072]))
        ecc_generate(s)
    return bytes(s)

def empty_form2(lba):
    return make_sector(lba, b'', 0, form2=True)

# ---------------------------------------------------------------- ISO 9660
def both16(v): return struct.pack('<H', v) + struct.pack('>H', v)
def both32(v): return struct.pack('<I', v) + struct.pack('>I', v)

def dir_time(t):
    g = time.gmtime(t)
    return bytes([g.tm_year - 1900, g.tm_mon, g.tm_mday, g.tm_hour, g.tm_min, g.tm_sec, 0])

def vol_time(t):
    g = time.gmtime(t)
    return time.strftime('%Y%m%d%H%M%S', g).encode() + b'00' + b'\0'

def xa_attr(is_dir, form2=False, file_no=0):
    # owner id, group id, attributes, "XA", file number, reserved
    attr = 0x0555            # read/execute for owner, group, world
    if is_dir:
        attr |= 0x8800       # directory + form 1
    elif form2:
        attr |= 0x1000       # form 2
    else:
        attr |= 0x0800       # form 1
    return struct.pack('>HHH', 0, 0, attr) + b'XA' + bytes([file_no]) + b'\0' * 5

def dir_record(name, extent, size, t, is_dir, form2=False, file_no=0):
    nb = name
    rec = bytearray()
    rec += bytes([0, 0])                    # length, ext attr length (fill later)
    rec += both32(extent) + both32(size)
    rec += dir_time(t)
    rec += bytes([2 if is_dir else 0, 0, 0])  # flags, unit size, gap size
    rec += both16(1)
    rec += bytes([len(nb)]) + nb
    if len(rec) % 2:
        rec += b'\0'
    rec += xa_attr(is_dir, form2, file_no)
    rec[0] = len(rec)
    return bytes(rec)

def pad(b, n, fill=b' '):
    b = b[:n]
    return b + fill * (n - len(b))

def build(out_base, volume_id, app_path, others):
    files = [app_path] + list(others)
    now = time.time()
    names = []
    for f in files:
        n = os.path.basename(f).upper()
        if ';' not in n:
            n += ';1'
        names.append(n)
    app_name = names[0]

    PVD, TERM, PT_L, PT_L2, PT_M, PT_M2, ROOT = 16, 17, 18, 19, 20, 21, 22
    rtf = [f.upper().endswith('.RTF') for f in files]   # pre-built Form 2 records
    sizes = [os.path.getsize(f) for f in files]
    nsec = [d // 2328 if r else max(1, (d + 2047) // 2048) for d, r in zip(sizes, rtf)]
    # the root directory: records may not cross a sector
    recs = [dir_record(names[i].encode(), 0, 0, now, False) for i in range(len(files))]
    nroot, used = 1, 2 * 34
    used = 2 * 34
    for i in sorted(range(len(files)), key=lambda i: names[i]):
        l = len(recs[i])
        if used + l > 2048: nroot += 1; used = 0
        used += l
    lba = ROOT + nroot
    extents = []
    for n in nsec:
        extents.append(lba)
        lba += n
    volume_size = lba

    # root directory (one sector)
    order = sorted(range(len(files)), key=lambda i: names[i])
    root = bytearray()
    root += dir_record(b'\0', ROOT, 2048 * nroot, now, True)
    root += dir_record(b'\1', ROOT, 2048 * nroot, now, True)
    for i in order:
        size = nsec[i] * 2048 if rtf[i] else sizes[i]
        r = dir_record(names[i].encode(), extents[i], size, now, False, rtf[i], 1 if rtf[i] else 0)
        if len(root) % 2048 + len(r) > 2048: root += bytes(2048 - len(root) % 2048)
        root += r
    root += bytes(-len(root) % 2048)
    assert len(root) == 2048 * nroot

    # path tables: just the root
    pt_l = bytes([1, 0]) + struct.pack('<I', ROOT) + struct.pack('<H', 1) + b'\0\0'
    pt_m = bytes([1, 0]) + struct.pack('>I', ROOT) + struct.pack('>H', 1) + b'\0\0'

    root_rec = dir_record(b'\0', ROOT, 2048 * nroot, now, True)
    root_rec = root_rec[:34]                # PVD holds a bare 34-byte record
    root_rec = bytes([34]) + root_rec[1:]

    pvd = bytearray(2048)
    pvd[0] = 1
    pvd[1:6] = b'CD001'
    pvd[6] = 1
    pvd[8:40] = pad(b'CD-RTOS CD-BRIDGE', 32)
    pvd[40:72] = pad(volume_id.upper().encode(), 32)
    pvd[80:88] = both32(volume_size)
    pvd[120:124] = both16(1)
    pvd[124:128] = both16(1)
    pvd[128:132] = both16(2048)
    pvd[132:140] = both32(len(pt_l))
    pvd[140:144] = struct.pack('<I', PT_L)
    pvd[144:148] = struct.pack('<I', PT_L2)
    pvd[148:152] = struct.pack('>I', PT_M)
    pvd[152:156] = struct.pack('>I', PT_M2)
    pvd[156:190] = root_rec
    pvd[190:318] = pad(b'', 128)               # volume set
    pvd[318:446] = pad(b'', 128)               # publisher
    pvd[446:574] = pad(b'', 128)               # preparer
    pvd[574:702] = pad(app_name.encode(), 128) # application id = boot module
    pvd[702:739] = pad(b'', 37)
    pvd[739:776] = pad(b'', 37)
    pvd[776:813] = pad(b'', 37)
    pvd[813:830] = vol_time(now)
    pvd[830:847] = vol_time(now)
    pvd[847:864] = b'0' * 16 + b'\0'
    pvd[864:881] = b'0' * 16 + b'\0'
    pvd[881] = 1
    pvd[1024:1032] = b'CD-XA001'               # XA marker (offset 1024)

    term = bytearray(2048)
    term[0] = 255
    term[1:6] = b'CD001'
    term[6] = 1

    f = open(out_base + '.bin', 'wb')
    for l in range(16):
        f.write(empty_form2(l))
    f.write(make_sector(PVD, pvd, SM_DATA | SM_EOR))
    f.write(make_sector(TERM, term, SM_DATA | SM_EOR | SM_EOF))
    f.write(make_sector(PT_L, pt_l, SM_DATA | SM_EOR | SM_EOF))
    f.write(make_sector(PT_L2, pt_l, SM_DATA | SM_EOR | SM_EOF))
    f.write(make_sector(PT_M, pt_m, SM_DATA | SM_EOR | SM_EOF))
    f.write(make_sector(PT_M2, pt_m, SM_DATA | SM_EOR | SM_EOF))
    for k in range(nroot):
        f.write(make_sector(ROOT + k, root[2048 * k:2048 * (k + 1)], SM_DATA | ((SM_EOR | SM_EOF) if k == nroot - 1 else 0)))
    for i in range(len(files)):
        d = open(files[i], 'rb').read()
        if rtf[i]:
            for k in range(nsec[i]):
                rec = d[k * 2328:(k + 1) * 2328]
                fno, chan, sm, coding = rec[0], rec[1], rec[2], rec[3]
                if sm & SM_FORM2:
                    f.write(make_sector(extents[i] + k, rec[4:], sm & ~SM_FORM2, True, fno, chan, coding, True))
                else:           # a Form 1 data sector (2048 bytes) in the real-time file
                    f.write(make_sector(extents[i] + k, rec[4:2052], sm, False, fno, chan, coding))
            continue
        n = max(1, (len(d) + 2047) // 2048)
        for k in range(n):
            sm = SM_DATA | ((SM_EOR | SM_EOF) if k == n - 1 else 0)
            f.write(make_sector(extents[i] + k, d[k * 2048:(k + 1) * 2048], sm))
    # a little run-out so the drive has something after the last file
    for k in range(volume_size, volume_size + 150):
        f.write(empty_form2(k))
    total = volume_size + 150
    f.close()
    with open(out_base + '.cue', 'w', newline='\r\n') as f:
        f.write('FILE "%s.bin" BINARY\n  TRACK 01 MODE2/2352\n    INDEX 01 00:00:00\n' % os.path.basename(out_base))
    print('wrote %s.bin (%d sectors, %.1f min), boot module %s' % (out_base, total, total / 4500, app_name))

if __name__ == '__main__':
    if len(sys.argv) < 4:
        sys.exit(__doc__)
    build(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4:])
