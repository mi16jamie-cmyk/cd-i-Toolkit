#!/usr/bin/env python3
"""mkpatch.py - patches between disc images (.bin, 2352-byte sectors)

    mkpatch.py make  OLD.bin NEW.bin PATCH.gz     make a patch
    mkpatch.py apply OLD.bin PATCH.gz NEW.bin     rebuild NEW from OLD + patch

For sharing a port without sharing the game: build your disc from the
original game's files, then make a patch against a disc image anyone with
the original can make (or against the original game's own disc image). The
patch holds only what the original doesn't: your program and whatever your
tools made differently. Also handy for sending a new build of a big disc:
the patch against the last build is small.

A sector of NEW that is a sector of OLD (anywhere in it; the address bytes
don't count, and Mode 2's EDC/ECC leave them out) is copied from OLD with
its address rewritten; the others are carried in the patch.
Patch records: 'C' old_first count | 'L' count + the sectors.
"""
import sys, gzip, struct, hashlib
S = 2352
def bcd(n): return ((n // 10) << 4) | (n % 10)
def addr(b, i, lba):
    a = lba + 150
    b[i + 12] = bcd(a // 4500); b[i + 13] = bcd((a // 75) % 60); b[i + 14] = bcd(a % 75)
def key(sec): return hashlib.md5(sec[:12] + sec[15:]).digest()
if len(sys.argv) != 5 or sys.argv[1] not in ('make', 'apply'):
    sys.exit(__doc__)
if sys.argv[1] == 'make':
    old, new, out = sys.argv[2:5]
    idx = {}
    with open(old, 'rb') as f:
        i = 0
        while True:
            s = f.read(S)
            if not s: break
            idx.setdefault(key(s), i); i += 1
    o = gzip.open(out, 'wb', 1)
    lits = []; run = None; nl = nc = 0
    def flush():
        global run, lits
        if lits: o.write(b'L' + struct.pack('>I', len(lits)) + b''.join(lits)); lits = []
        if run: o.write(b'C' + struct.pack('>II', run[0], run[1])); run = None
    with open(new, 'rb') as f:
        while True:
            s = f.read(S)
            if not s: break
            j = idx.get(key(s))
            if j is not None:
                if lits: flush()
                if run and run[0] + run[1] == j: run[1] += 1
                else:
                    if run: flush()
                    run = [j, 1]
                nc += 1
            else:
                if run: flush()
                lits.append(s); nl += 1
                if len(lits) >= 4096: flush()
    flush(); o.close()
    print('copied', nc, 'sectors, carried', nl)
else:
    old, patch, new = sys.argv[2:5]
    p = gzip.open(patch, 'rb')
    with open(old, 'rb') as f, open(new, 'wb') as o:
        lba = 0
        while True:
            t = p.read(1)
            if not t: break
            if t == b'L':
                n = struct.unpack('>I', p.read(4))[0]
                o.write(p.read(n * S)); lba += n
            else:
                j, n = struct.unpack('>II', p.read(8))
                f.seek(j * S)
                while n:
                    k = min(n, 512)
                    b = bytearray(f.read(k * S))
                    for i in range(0, len(b), S): addr(b, i, lba); lba += 1
                    o.write(b); n -= k
