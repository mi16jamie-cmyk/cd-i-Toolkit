#!/usr/bin/env python3
"""mkstream.py - video and music for a CD-i program (real-time files)

  MPEG (needs the Digital Video Cartridge; stream_play(..., STREAM_MPEG)):
    mkstream.py OUT.RTF --mpeg --video clip.mp4 [--audio music.wav]
    mkstream.py OUT.RTF --mpeg --audio music.wav          (music only)
  ADPCM sound (any CD-i player; STREAM_ADPCM):
    mkstream.py OUT.RTF --adpcm --audio music.wav [--stereo] [--level B]
  MPEG picture with ADPCM sound (STREAM_MPEG | STREAM_ADPCM):
    mkstream.py OUT.RTF --mpeg --adpcm --video clip.mp4 [--audio sound.wav]

Inputs are anything ffmpeg reads; with --video and no --audio the video's
own sound is used. The disc delivers 75 sectors a second (single speed),
and every sector is placed so it arrives when it is due:
  - MPEG: MPEG-1 video (352 x 288, 25 fps, 1100 kbit/s by default) and
    MPEG-1 layer II audio (44.1 kHz stereo, 224 kbit/s) in 2324-byte packs
    (the Video CD format), each in the sector its time stamp says;
  - ADPCM: one sound sector every 16 (level C mono, 18.9 kHz), 8 (level C
    stereo, or level B mono 37.8 kHz) or 4 (level B stereo);
  - the sectors left over are empty, on channel 31, which the library's
    play leaves out.
Everything is on channel 0. With --mpeg and --adpcm the video bit rate is
lowered to leave room for the sound sectors.

Records are 4 subheader bytes + 2324 bytes each, for mkcdi.py (files named
.RTF go on the disc as real-time Form 2 files).
"""
import sys, os, subprocess, tempfile, argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from adpcm import encode, read_audio

SM_EOR, SM_AUDIO, SM_DATA, SM_FORM2, SM_RT, SM_EOF = 1, 4, 8, 32, 64, 128
ap = argparse.ArgumentParser(description=__doc__.split('\n')[1])
ap.add_argument('out')
ap.add_argument('--video'); ap.add_argument('--audio')
ap.add_argument('--mpeg', action='store_true'); ap.add_argument('--adpcm', action='store_true')
ap.add_argument('--size', default='352x288', help='MPEG picture size (default 352x288)')
ap.add_argument('--fps', type=float, default=25)
ap.add_argument('--vbitrate', type=int, help='MPEG video kbit/s (default 1100, or 1000 with --adpcm)')
ap.add_argument('--abitrate', type=int, default=224, help='MPEG audio kbit/s (default 224)')
ap.add_argument('--volume', type=float, default=1.0, help='sound gain (default 1.0)')
ap.add_argument('--stereo', action='store_true', help='ADPCM in stereo')
ap.add_argument('--level', default='C', choices='BC', help='ADPCM level: C 18.9 kHz, B 37.8 kHz')
ap.add_argument('--duration', type=float, help='cut (or loop the sound) to this many seconds')
a = ap.parse_args()
if not (a.mpeg or a.adpcm): ap.error('say --mpeg and/or --adpcm')
if a.adpcm and not a.audio and not a.video: ap.error('--adpcm needs --audio (or a --video with sound)')
if a.mpeg and not (a.video or a.audio): ap.error('--mpeg needs --video and/or --audio')
tmp = tempfile.mkdtemp()

# ---------------------------------------------------------------- MPEG packs
packs = []
if a.mpeg:
    mpg = os.path.join(tmp, 's.mpg')
    cmd = ['ffmpeg', '-y', '-v', 'error']
    if a.video: cmd += ['-i', a.video]
    mpeg_audio = not a.adpcm and (a.audio or a.video)
    if a.audio and mpeg_audio:
        if a.duration: cmd += ['-stream_loop', '-1']
        cmd += ['-i', a.audio]
    if a.duration: cmd += ['-t', '%.3f' % a.duration]
    if a.video:
        cmd += ['-map', '0:v:0']
        w, h = a.size.split('x')
        vb = a.vbitrate or (1000 if a.adpcm else 1100)
        cmd += ['-vf', 'scale=%s:%s:flags=lanczos,fps=%g,setsar=1' % (w, h, a.fps), '-c:v', 'mpeg1video',
                '-b:v', '%dk' % vb, '-minrate', '%dk' % vb, '-maxrate', '%dk' % vb, '-bufsize', '327680',
                '-g', '12', '-bf', '2']
    if mpeg_audio:
        cmd += ['-map', ('1:a:0' if a.video and a.audio else '0:a:0?'), '-c:a', 'mp2', '-ar', '44100', '-ac', '2',
                '-b:a', '%dk' % a.abitrate, '-af', 'volume=%g,alimiter=limit=0.97:level=disabled' % a.volume]
    else:
        cmd += ['-an']
    cmd += ['-f', 'vcd', '-packetsize', '2324', mpg]
    subprocess.check_call(cmd)
    d = open(mpg, 'rb').read()
    assert len(d) % 2324 == 0
    packs = [d[i:i + 2324] for i in range(0, len(d), 2324)]

def scr(p):
    b = p[4:9]
    return (((b[0] >> 1) & 7) << 30) | (b[1] << 22) | ((b[2] >> 1) << 15) | (b[3] << 7) | (b[4] >> 1)

# ---------------------------------------------------------------- ADPCM
asec, every, coding = [], 0, 0
if a.adpcm:
    rate = 18900 if a.level == 'C' else 37800
    src = a.audio or a.video
    s = read_audio(src, rate, a.stereo, gain=a.volume)
    if a.duration:
        n = int(a.duration * rate)
        reps = -(-n // max(1, len(s)))
        s = np.concatenate([s] * reps)[:n]
    nsec, data = encode(s, a.stereo)
    asec = [data[i * 2304:(i + 1) * 2304] + bytes(20) for i in range(nsec)]
    every = {('C', False): 16, ('C', True): 8, ('B', False): 8, ('B', True): 4}[(a.level, a.stereo)]
    coding = (1 if a.stereo else 0) | (4 if a.level == 'C' else 0)

# ---------------------------------------------------------------- placing
LEAD = 4                            # the first sound sector
VLEAD = 30 if asec else 0           # pictures this far ahead of their time
want = [round((scr(p) - scr(packs[0])) * 75 / 90000) for p in packs] if packs else []
n = max([want[-1] + 1 if want else 0, LEAD + every * len(asec)]) + 8
slots = [None] * (n + len(packs) + 16)
for i, x in enumerate(asec):
    slots[LEAD + every * i] = ('a', x)
k = 0
for p, w in zip(packs, want):
    k = max(k, w - VLEAD)
    while slots[k] is not None: k += 1
    slots[k] = ('v', p); k += 1
while slots and slots[-1] is None: slots.pop()
vpos = [i for i, x in enumerate(slots) if x and x[0] == 'v']
lateness = [p_ - w for p_, w in zip(vpos, want)]
worst = max(lateness) if lateness else 0     # (the decoder's buffer covers ~15 sectors)

o = bytearray()
for i, s in enumerate(slots):
    end = (SM_EOR | SM_EOF) if i == len(slots) - 1 else 0
    if s is None:
        o += bytes([1, 31, SM_FORM2 | SM_RT | end, 0]) + bytes(2324)
    elif s[0] == 'a':
        o += bytes([1, 0, SM_AUDIO | SM_FORM2 | SM_RT | end, coding]) + s[1]
    else:
        o += bytes([1, 0, SM_DATA | SM_FORM2 | SM_RT | end, 0]) + s[1]
open(a.out, 'wb').write(o)
print('%s: %d sectors (%.1f s), %d MPEG packs, %d ADPCM sectors%s' % (
    a.out, len(slots), len(slots) / 75, len(packs), len(asec),
    (', up to %d sectors late: lower --vbitrate' % worst) if worst > 12 else ''))
