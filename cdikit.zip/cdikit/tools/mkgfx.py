#!/usr/bin/env python3
"""mkgfx.py - pictures for a CD-i program: a bank of images with one palette

    mkgfx.py OUT.GFX [--header out.h] [--colours N] IMAGE[@WxH] ...

Each IMAGE (PNG, JPEG, GIF ...) becomes one image in the bank; with @WxH a
sprite sheet is cut into W x H frames (left to right, top to bottom), each
its own image. All images share one palette of up to 255 colours (made
from all of them together; --colours lowers it, leaving room for colours
you set yourself with gfx_palette). Colour 0 is see-through: transparent
pixels (alpha < 128) become colour 0, so sprites can be drawn over
anything with gfx_draw(). A full-screen picture is 384 x 280.

--header writes a C header naming the images: IMG_<NAME> (and IMG_<NAME>_0,
_1 ... for a sheet's frames), so the program can say
gfx_bank_image(bank, IMG_SHIP).

Images are cropped to their visible pixels (the see-through border costs
time on every draw); each keeps its full size and where the crop sits in
it, and gfx_draw puts it in the same place as the uncropped picture.
--no-crop keeps them whole.

Format (big-endian): "CDIG", u16 version 3, u16 count, 256 x u32 colours
(0x00RRGGBB), count x u32 offsets from the file's start. Each image: u16 w,
u16 h (the cropped size), u16 full w, u16 full h, s16 x, s16 y (the crop's
place in the full picture), u32 offset (from the image's start) of its
runs, then w*h colour numbers, padded to an even length; then the runs,
row by row: pairs of u16 (skip, length) for the solid stretches of the
row, ended by 0xFFFF (so gfx_draw copies only the solid pixels).
"""
import sys, os, re, struct, argparse
from PIL import Image
import numpy as np
# (Pillow 9.1 moved these constants into enums; older ones have them on Image)
MEDIANCUT = getattr(getattr(Image, 'Quantize', Image), 'MEDIANCUT', 0)
DITHER = getattr(getattr(Image, 'Dither', Image), 'FLOYDSTEINBERG', 3)
NODITHER = getattr(getattr(Image, 'Dither', Image), 'NONE', 0)

ap = argparse.ArgumentParser(description=__doc__.split('\n')[1])
ap.add_argument('out')
ap.add_argument('images', nargs='+')
ap.add_argument('--header')
ap.add_argument('--colours', type=int, default=255)
ap.add_argument('--no-crop', action='store_true')
a = ap.parse_args()
ncol = max(1, min(255, a.colours))

items = []                          # (name, RGBA image)
for spec in a.images:
    m = re.match(r'(.*)@(\d+)x(\d+)$', spec)
    path, fw, fh = (m.group(1), int(m.group(2)), int(m.group(3))) if m else (spec, 0, 0)
    im = Image.open(path).convert('RGBA')
    name = re.sub(r'\W', '_', os.path.splitext(os.path.basename(path))[0]).upper()
    if not fw:
        items.append((name, im))
        continue
    k = 0
    for y in range(0, im.height - fh + 1, fh):
        for x in range(0, im.width - fw + 1, fw):
            items.append(('%s_%d' % (name, k), im.crop((x, y, x + fw, y + fh)))); k += 1

# one palette for everything: quantise all the opaque pixels together
W = max(im.width for _, im in items)
H = sum(im.height for _, im in items)
sheet = Image.new('RGB', (W, H), (0, 0, 0))
mask = Image.new('L', (W, H), 0)
y = 0
for _, im in items:
    sheet.paste(im.convert('RGB'), (0, y))
    mask.paste(im.getchannel('A'), (0, y))
    y += im.height
# only opaque pixels decide the palette
rgb = np.asarray(sheet).reshape(-1, 3)
px = rgb[np.asarray(mask).reshape(-1) >= 128]
if not len(px): px = np.zeros((1, 3), np.uint8)
cols = np.unique(px, axis=0)
if len(cols) <= ncol:                # few enough colours: kept exactly
    palette = [tuple(int(v) for v in c) for c in cols]
    key = lambda a_: (a_[..., 0].astype(np.int64) << 16) | (a_[..., 1].astype(np.int64) << 8) | a_[..., 2]
    lut = {int(k): i + 1 for i, k in enumerate(key(cols))}
    def index(im):
        a_ = np.asarray(im)
        k = key(a_[..., :3]).reshape(-1)
        out = np.array([lut.get(int(v), 0) for v in k], np.uint8)
        out[a_[..., 3].reshape(-1) < 128] = 0
        return out.tobytes()
else:                                # else a median-cut palette, dithered
    src = Image.fromarray(px.reshape(1, -1, 3).astype(np.uint8), 'RGB')
    q = src.quantize(colors=ncol, method=MEDIANCUT, dither=NODITHER)
    pal = q.getpalette()[:3 * ncol]
    palette = [tuple(pal[3 * i:3 * i + 3]) for i in range(len(pal) // 3)]
    pimg = Image.new('P', (1, 1)); pimg.putpalette(pal + [0] * (768 - len(pal)))
    def index(im):
        a_ = np.asarray(im)
        idx = np.asarray(im.convert('RGB').quantize(palette=pimg, dither=DITHER)).reshape(-1)
        out = (idx.astype(np.uint16) + 1).astype(np.uint8)
        out[a_[..., 3].reshape(-1) < 128] = 0
        return out.tobytes()

colours = [0] + [(r << 16) | (g << 8) | b for r, g, b in palette]
colours += [0] * (256 - len(colours))
body = bytearray()
offs = []
base = 8 + 1024 + 4 * len(items)
def runs(px, w, h):
    o = bytearray()
    for y in range(h):
        row = px[y * w:(y + 1) * w]; x = 0; last = 0
        while x < w:
            while x < w and row[x] == 0: x += 1
            if x >= w: break
            x0 = x
            while x < w and row[x] != 0: x += 1
            o += struct.pack('>HH', x0 - last, x - x0); last = x
        o += b'\xff\xff'
    return bytes(o)
for name, im in items:
    offs.append(base + len(body))
    fw, fh = im.width, im.height
    box = None if a.no_crop else im.getchannel('A').point(lambda v: 255 if v >= 128 else 0).getbbox()
    if box is None: box = (0, 0, fw, fh)          # (none visible, or --no-crop: whole)
    cim = im.crop(box)
    px = index(cim)
    rec = bytearray(px)
    if len(rec) % 2: rec += b'\0'
    body += struct.pack('>HHHHhhI', cim.width, cim.height, fw, fh, box[0], box[1], 16 + len(rec)) + rec \
        + runs(px, cim.width, cim.height)
out = b'CDIG' + struct.pack('>HH', 3, len(items)) + b''.join(struct.pack('>I', c) for c in colours)
out += b''.join(struct.pack('>I', o) for o in offs) + body
open(a.out, 'wb').write(out)
print('%s: %d images, %d colours, %d bytes' % (a.out, len(items), len(palette), len(out)))
if a.header:
    g = re.sub(r'\W', '_', os.path.basename(a.out)).upper()
    with open(a.header, 'w') as f:
        f.write('/* made by mkgfx.py from %s */\n#ifndef %s_H\n#define %s_H\n' % (' '.join(a.images), g, g))
        for i, (name, im) in enumerate(items):
            f.write('#define IMG_%s %d   /* %d x %d */\n' % (name, i, im.width, im.height))
        f.write('#define IMG_COUNT %d\n#define GFX_COLOURS %d   /* colours used: 1..%d */\n#endif\n'
                % (len(items), len(palette), len(palette)))
